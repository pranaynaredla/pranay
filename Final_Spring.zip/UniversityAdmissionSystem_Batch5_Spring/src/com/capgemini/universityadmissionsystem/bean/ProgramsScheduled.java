package com.capgemini.universityadmissionsystem.bean;

import java.io.Serializable;
import java.sql.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

@Entity
@Table(name = "Programs_scheduled")
@NamedQueries({
		@NamedQuery(name = "getProgramsScheduled", query = "select programsScheduled from ProgramsScheduled programsScheduled"),
		@NamedQuery(name = "getProgramsScheduledId", query = "SELECT ps FROM ProgramsScheduled ps where ps.programName=:pn") })

public class ProgramsScheduled implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "scheduled_program_id")
	@NotEmpty(message = "Required field")
	@Pattern(regexp = "^[0-9]{3,4}$", message = "Only upto 5 characters allowed")
	private String scheduledProgramId;

	@Column(name = "program_name")
	@NotEmpty(message = "Required field")
	@Pattern(regexp = "^[A-Za-z][A-Za-z0-9 ]{1,4}$", message = "Only upto 5 characters allowed")
	private String programName;

	@Column(name = "location")
	@NotEmpty(message = "Required field")
	@Pattern(regexp = "^[A-Za-z]{1,10}$", message = "Only upto 10 characters allowed")
	private String location;

	@Transient
	@NotEmpty(message = "Required field")
	@Pattern(regexp = "^(3[01]|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/201[89]$", message = "Invalid Date")
	private String sDate;

	@Transient
	@NotEmpty(message = "Required field")
	@Pattern(regexp = "^(3[01]|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/201[89]$", message = "Invalid Date")
	private String eDate;

	@Column(name = "start_date")
	private Date startDate;

	@Column(name = "end_date")
	private Date endDate;

	@Column(name = "sessions_per_week")
	@NotNull(message = "Required field")
	@Range(min = 1, max = 7)
	private Integer sessionsPerWeek;

	public ProgramsScheduled() {
	}

	public String getsDate() {
		return sDate;
	}

	public void setsDate(String sDate) {
		this.sDate = sDate;
	}

	public String geteDate() {
		return eDate;
	}

	public void seteDate(String eDate) {
		this.eDate = eDate;
	}

	public String getScheduledProgramId() {
		return scheduledProgramId;
	}

	public void setScheduledProgramId(String scheduledProgramId) {
		this.scheduledProgramId = scheduledProgramId;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Integer getSessionsPerWeek() {
		return sessionsPerWeek;
	}

	public void setSessionsPerWeek(Integer sessionsPerWeek) {
		this.sessionsPerWeek = sessionsPerWeek;
	}

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "scheduled_program_id")
	private Set<Application> applications;

	public Set<Application> getApplications() {
		return applications;
	}

	public void setApplications(Set<Application> applications) {
		this.applications = applications;
	}
}
