package com.capgemini.universityadmissionsystem.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.Range;

@Entity
@Table(name = "Programs_Offered")
@NamedQuery(name = "getProgamsOffered", query = "SELECT programsOffered FROM ProgramsOffered programsOffered")
public class ProgramsOffered {

	@Id
	@Column(name = "program_name")
	@NotBlank(message = "Required field")
	@Pattern(regexp = "^[A-Za-z][A-Za-z0-9 ]{1,4}$", message = "Only upto 5 characters allowed")
	private String programName;

	@Column(name = "description")
	@NotBlank(message = "Required field")
	@Pattern(regexp = "^[A-Za-z0-9][A-Za-z0-9 ]{1,19}$", message = "Only upto 20 characters allowed")
	private String programDescription;

	@Column(name = "applicant_eligibility")
	@NotBlank(message = "Required field")
	@Pattern(regexp = "^[A-Za-z0-9][A-Za-z0-9/. ]{1,39}$", message = "Only upto 40 characters allowed")
	private String applicantEligibility;

	@Column(name = "duration")
	@NotNull(message = "Required field")
	@Range(min = 1, max = 3)
	private Integer programDuration;

	@Column(name = "degree_certificate_offered")
	@NotBlank(message = "Required field")
	@Pattern(regexp = "^[A-Za-z0-9][A-Za-z0-9 ]{1,9}$", message = "Only upto 10 characters allowed")
	private String degreeCertOffered;

	public ProgramsOffered() {
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getProgramDescription() {
		return programDescription;
	}

	public void setProgramDescription(String programDescription) {
		this.programDescription = programDescription;
	}

	public String getApplicantEligibility() {
		return applicantEligibility;
	}

	public void setApplicantEligibility(String applicantEligibility) {
		this.applicantEligibility = applicantEligibility;
	}

	public Integer getProgramDuration() {
		return programDuration;
	}

	public void setProgramDuration(Integer programDuration) {
		this.programDuration = programDuration;
	}

	public String getDegreeCertOffered() {
		return degreeCertOffered;
	}

	public void setDegreeCertOffered(String degreeCertOffered) {
		this.degreeCertOffered = degreeCertOffered;
	}
}
