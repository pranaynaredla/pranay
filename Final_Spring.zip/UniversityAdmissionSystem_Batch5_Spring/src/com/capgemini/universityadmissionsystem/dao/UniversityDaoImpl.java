package com.capgemini.universityadmissionsystem.dao;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.universityadmissionsystem.bean.Application;
import com.capgemini.universityadmissionsystem.bean.Participants;
import com.capgemini.universityadmissionsystem.bean.ProgramsOffered;
import com.capgemini.universityadmissionsystem.bean.ProgramsScheduled;
import com.capgemini.universityadmissionsystem.bean.Users;

@Repository
@Transactional
@SuppressWarnings("unchecked")
public class UniversityDaoImpl implements IUniversityDao {

	@PersistenceContext
	EntityManager entityManager;

	Query query;

	@Override
	public List<Users> authenticateUser(Users users) {
		query = entityManager.createNamedQuery("validateLogin");
		query.setParameter("loginId", users.getLoginId());
		query.setParameter("password", users.getPassword());
		List<Users> list = query.getResultList();
		return list;
	}

	@Override
	public List<ProgramsOffered> displayProgramsOffered() {
		query = entityManager.createNamedQuery("getProgamsOffered");
		return query.getResultList();

	}

	@Override
	public List<ProgramsScheduled> displayProgramsScheduled() {
		query = entityManager.createNamedQuery("getProgramsScheduled");
		return query.getResultList();
	}

	@Override
	public Integer addApplicantDetails(Application application) {
		String string = null;
		LocalDate curDate = LocalDate.now();
		Date curSqlDate = Date.valueOf(curDate);
		java.util.Date date = null;
		Date sqlDate = null;
		string = application.getDob();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		try {
			date = dateFormat.parse(string);
			sqlDate = new Date(date.getTime());
			application.setDateOfBirth(sqlDate);
			application.setStatus("applied");
			application.setDateOfInterview(curSqlDate);
			entityManager.persist(application);
			entityManager.flush();
		} catch (Exception e) {
			e.getMessage();
		} finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}
		return application.getApplicantId();
	}

	@Override
	public List<Application> retrieveFilteredApplicants(ProgramsScheduled scheduled) {
		query = entityManager.createQuery(
				"SELECT a FROM Application a,ProgramsScheduled p WHERE a.scheduledProgramId=p.scheduledProgramId AND p.programName=:pname AND a.status=:status");
		query.setParameter("pname", scheduled.getProgramName());
		query.setParameter("status", "applied");
		return query.getResultList();
	}

	@Override
	public List<Application> applicantStatus(Integer id) {
		List<Application> list = null;
		query = entityManager.createNamedQuery("getApplicantStatus");
		query.setParameter("id", id);
		list = query.getResultList();
		return list;
	}

	@Override
	public List<Participants> displayParticipants() {
		query = entityManager.createNamedQuery("getParticipants");
		return query.getResultList();
	}

	@Override
	public List<Application> displayApplicants() {
		query = entityManager.createNamedQuery("getApplicants");
		return query.getResultList();
	}

	@Override
	public List<Application> getAcceptedApplicants() {
		LocalDate curDate = LocalDate.now();
		Date curSqlDate = Date.valueOf(curDate);
		query = entityManager.createNamedQuery("getAcceptedApplicantStatus", Application.class);
		query.setParameter("status", "accepted");
		query.setParameter("date", curSqlDate);
		return query.getResultList();
	}

	@Override
	public void confirmOrRejectApplicants(Integer applicantId, String applicantStatus) {
		query = entityManager.createNamedQuery("getConfirmRejectStatus");
		query.setParameter("status", applicantStatus);
		query.setParameter("id", applicantId);
		query.executeUpdate();
	}

	@Override
	public void deleteProgramOffered(String programName) {
		ProgramsOffered p = entityManager.find(ProgramsOffered.class, programName);
		entityManager.remove(p);
		Query query = entityManager.createNamedQuery("getProgramsScheduledId");
		query.setParameter("pn", programName);
		List<ProgramsScheduled> psList = query.getResultList();
		for (ProgramsScheduled ps : psList) {
			ProgramsScheduled pst = entityManager.find(ProgramsScheduled.class, ps.getScheduledProgramId());
			entityManager.remove(pst);
		}
	}

	@Override
	public void deleteProgramsScheduled(String scheduledId) {
		ProgramsScheduled p = entityManager.find(ProgramsScheduled.class, scheduledId);
		entityManager.remove(p);
	}

	@Override
	public void addProgramsOffered(ProgramsOffered programsOffered) {
		entityManager.persist(programsOffered);
		entityManager.flush();
	}

	@Override
	public void addProgramsScheduled(ProgramsScheduled programsScheduled) {

		Date sqlDate1 = null;
		java.util.Date date1 = null;

		Date sqlDate2 = null;
		java.util.Date date2 = null;

		String sDate = null;
		String eDate = null;

		sDate = programsScheduled.getsDate();
		eDate = programsScheduled.geteDate();

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		try {
			date1 = dateFormat.parse(sDate);
			sqlDate1 = new Date(date1.getTime());
			programsScheduled.setStartDate(sqlDate1);
			date2 = dateFormat.parse(eDate);
			sqlDate2 = new Date(date2.getTime());
			programsScheduled.setEndDate(sqlDate2);
			entityManager.persist(programsScheduled);
			entityManager.flush();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}
	}

	@Override
	public void updateApplicantStatus(String status, Integer applicantId, Date date) {
		query = entityManager.createNamedQuery("getUpdateStatus");
		query.setParameter("status", status);
		query.setParameter("date", date);
		query.setParameter("id", applicantId);
		query.executeUpdate();
	}

	@Override
	public List<Application> addParticipantDetails() {
		List<Application> list = null;
		query = entityManager.createQuery(
				"SELECT a FROM Application a WHERE a.status=:status AND a.applicantId NOT IN (SELECT p.applicantId FROM Participants p)");
		query.setParameter("status", "confirmed");
		list = query.getResultList();
		for (Application application : list) {
			Participants participants = new Participants();
			participants.setEmailId(application.getEmailId());
			participants.setApplicantId(application.getApplicantId());
			participants.setScheduledProgramId(application.getScheduledProgramId());
			entityManager.persist(participants);
			entityManager.flush();
		}
		return list;
	}
}
