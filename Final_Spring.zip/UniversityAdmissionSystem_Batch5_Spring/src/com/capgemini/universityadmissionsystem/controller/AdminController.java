package com.capgemini.universityadmissionsystem.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.universityadmissionsystem.bean.Participants;
import com.capgemini.universityadmissionsystem.bean.ProgramsOffered;
import com.capgemini.universityadmissionsystem.bean.ProgramsScheduled;
import com.capgemini.universityadmissionsystem.service.IUniversityService;

@Controller
public class AdminController {

	@Autowired
	IUniversityService service;

	@RequestMapping(value = "/admin")
	public String getAdminPage() {
		String view = "Adminpage";
		return view;
	}

	@RequestMapping("addPo")
	public ModelAndView addPo() {
		ModelAndView view = new ModelAndView("addProgOffered", "programsOffered", new ProgramsOffered());
		return view;
	}

	@RequestMapping("addPs")
	public ModelAndView addPs() {
		ModelAndView view = new ModelAndView("addProgScheduled", "programsScheduled", new ProgramsScheduled());
		return view;
	}

	@RequestMapping("removePo")
	public ModelAndView removePo() {
		ModelAndView view = new ModelAndView();
		List<ProgramsOffered> list = service.displayProgramsOffered();
		view.addObject("programsOfferedList", list);
		view.setViewName("Admin");
		return view;
	}

	@RequestMapping("removePs")
	public ModelAndView removePs() {
		ModelAndView view = new ModelAndView();
		List<ProgramsScheduled> list = service.displayProgramsScheduled();
		view.addObject("programsScheduledList", list);
		view.setViewName("Admin");
		return view;
	}

	@RequestMapping(value = "addProgramsOffered", method = RequestMethod.POST)
	public ModelAndView addProgramsOffered(@ModelAttribute("programsOffered") @Valid ProgramsOffered programsOffered,
			BindingResult bindingResult) {
		ModelAndView view = new ModelAndView();
		if (bindingResult.hasErrors()) {
			view.setViewName("addProgOffered");
		} else {
			service.addProgramsOffered(programsOffered);
			view.addObject("message", "Program Offered has been added successfully");
			view.setViewName("Admin");
		}
		return view;
	}

	@RequestMapping("addScheduledProgram")
	public ModelAndView addProgramsScheduled(
			@ModelAttribute("programsScheduled") @Valid ProgramsScheduled programsScheduled,
			BindingResult bindingResult) {
		ModelAndView view = new ModelAndView();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate fdate = LocalDate.parse(programsScheduled.getsDate(), formatter);
		LocalDate tdate = LocalDate.parse(programsScheduled.geteDate(), formatter);
		LocalDate cdate = LocalDate.now();
		if (!((fdate.isAfter(cdate) || fdate.isEqual(cdate)) && (tdate.isAfter(cdate))
				&& ((fdate.isBefore(tdate))))) {
			view.addObject("dateMsg",
					"starting date must be greater than current date and less than ending date");
			view.setViewName("addProgScheduled");
		}
		else if (bindingResult.hasErrors()) {
			view.setViewName("addProgScheduled");
		} else {
			service.addProgramsScheduled(programsScheduled);
			view.addObject("message", "Scheduled Program has been added successfully");
			view.setViewName("Admin");
		}
		return view;
	}

	@RequestMapping("removeProgramsOffered")
	public ModelAndView removeProgramsOffered(@RequestParam("programName") String programName) {
		service.deleteProgramOffered(programName);
		ModelAndView view = new ModelAndView();
		view.addObject("message", "Program Offered has been deleted successfully");
		view.setViewName("Admin");
		return view;
	}

	@RequestMapping("removeProgramsScheduled")
	public ModelAndView removeProgramsScheduled(@RequestParam("scheduledId") String scheduledId) {
		ModelAndView view = new ModelAndView();
		service.deleteProgramsScheduled(scheduledId);
		view.addObject("message", "Scheduled Program has been deleted successfully");
		view.setViewName("Admin");
		return view;
	}

	@RequestMapping("viewAdminParticipants")
	public ModelAndView getParticipants() {
		ModelAndView view = new ModelAndView("Admin");
		List<Participants> list = service.displayParticipants();
		view.addObject("participantList", list);
		return view;
	}

	@RequestMapping(value = "toAdmin", method = RequestMethod.POST)
	public String getBackAdmin() {
		String view = "Admin";
		return view;
	}
}
