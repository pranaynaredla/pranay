package com.cg.traineemanagement.controller;

import java.util.ArrayList;

import oracle.net.aso.n;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.traineemanagement.bean.Trainee;
import com.cg.traineemanagement.bean.UserLogin;
import com.cg.traineemanagement.service.ITraineeService;
import com.sun.org.apache.bcel.internal.generic.NEW;

@Controller
public class TraineeController {
	
	@Autowired
	ITraineeService service;
	
	@RequestMapping("/index")
	public ModelAndView getHomePage(){
		ModelAndView view=new ModelAndView("LoginPage","ulogin",new UserLogin()); 
		return view;
	}
	
	@RequestMapping("/login")
	public ModelAndView verifyLogin(@ModelAttribute("ulogin") UserLogin login){
		boolean result=false;
		ModelAndView view=new ModelAndView();
		/*view.addObject("trainee", new Trainee());*/
		result=service.login(login);
		if (result==true) {
			view.setViewName("HomePage");
		} else {
			view=new ModelAndView("LoginPage","ulogin",new UserLogin()); 
			view.addObject("message", "Please enter valid credentials");
		}
		return view;
	}
	
	@RequestMapping("add")
	public ModelAndView addPage(){
		ModelAndView view=new ModelAndView("AddTrainee","trainee",new Trainee());
		ArrayList<String> list=new ArrayList<String>();
		list.add("Chennai");
		list.add("Banglore");
		list.add("Pune");
		list.add("Mumbai");
		view.addObject("locations", list);
		ArrayList<String> list1=new ArrayList<String>();
		list1.add("JEE");
		list1.add(".NET");
		list1.add("VNV");
		list1.add("ORAPPS");
		list1.add("BI");
		view.addObject("domains", list1);
		return view;
	}
	
	@RequestMapping("/store")
	public ModelAndView addTrainee(@ModelAttribute("trainee") Trainee trainee){
		service.addDetails(trainee);
		ModelAndView view=new ModelAndView();
		view.setViewName("HomePage");
		return view;
	}
	
	@RequestMapping("/delete")
	public ModelAndView deletePage(){
		ModelAndView view=new ModelAndView("DeleteTrainee","trainee",new Trainee());
		return view;
	}
	
	@RequestMapping("/deleteTrainee")
	public ModelAndView getdeleteTrainee(@ModelAttribute("trainee") Trainee trainee){
		ModelAndView view=new ModelAndView("DeleteTrainee","trainee",new Trainee());
		ArrayList<Trainee> list=service.getDeleteDetails(trainee.getTraineeId());
		view.addObject("deletelist", list);
		return view;
	}
	
	@RequestMapping("/deletebyTrainee")
	public ModelAndView deleteTrainee(@ModelAttribute("trainee") Trainee trainee){
		service.deleteTrainee(trainee);
		ModelAndView view=new ModelAndView();
		view.setViewName("HomePage");
		return view;
	}
	
	@RequestMapping("/modify")
	public ModelAndView modifyPage(){
		ModelAndView view=new ModelAndView("modifyTrainee","trainee",new Trainee());
		return view;
	}
	
	@RequestMapping("/modifyTrainee")
	public ModelAndView getmodifyTrainee(@ModelAttribute("trainee") Trainee trainee){
		ModelAndView view=new ModelAndView("modifyTrainee","trainee",new Trainee());
		ArrayList<Trainee> list=service.getmodifyDetails(trainee.getTraineeId());
		view.addObject("modifylist", list);
		return view;
	}
	
	@RequestMapping("/modifybyTrainee")
	public ModelAndView modifyTrainee(@ModelAttribute("trainee") Trainee trainee){
		service.modifyTrainee(trainee);
		ModelAndView view=new ModelAndView();
		view.setViewName("HomePage");
		return view;
	}
	
	@RequestMapping("/retrieve")
	public ModelAndView retrievePage(){
		ModelAndView view=new ModelAndView("retrieveTrainee","trainee",new Trainee());
		return view;
	}
	
	@RequestMapping("/retrieveTrainee")
	public ModelAndView retrieveTrainee(@ModelAttribute("trainee") Trainee trainee){
		ModelAndView view=new ModelAndView("retrieveTrainee","trainee",new Trainee());
		ArrayList<Trainee> list=service.retrieveDetails(trainee.getTraineeId());
		view.addObject("retrievelist", list);
		return view;
	}
	
	@RequestMapping("/retrieveAll")
	public ModelAndView retrieveAllTrainee(){
		ModelAndView view=new ModelAndView("retrieveAllTrainee","trainee",new Trainee());
		ArrayList<Trainee> list=service.retrieveAllDetails();
		view.addObject("retrievealllist", list);
		return view;
	}
}
