package com.cg.traineemanagement.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.traineemanagement.bean.Trainee;
import com.cg.traineemanagement.bean.UserLogin;
import com.cg.traineemanagement.dao.ITraineeDao;

@Service
public class TraineeServiceImpl implements ITraineeService {

	@Autowired
	ITraineeDao dao;

	@Override
	public boolean login(UserLogin login) {
		return dao.login(login);
	}

	@Override
	public void addDetails(Trainee trainee) {
		dao.addDetails(trainee);
	}

	@Override
	public ArrayList<Trainee> getDeleteDetails(Integer traineeId) {
		return dao.getDeleteDetails(traineeId);
	}

	@Override
	public void deleteTrainee(Trainee trainee) {
		dao.deleteTrainee(trainee);
	}

	@Override
	public ArrayList<Trainee> getmodifyDetails(Integer traineeId) {
		return dao.getmodifyDetails(traineeId);
	}

	@Override
	public void modifyTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		dao.modifyTrainee(trainee);
	}

	@Override
	public ArrayList<Trainee> retrieveDetails(Integer traineeId) {
		// TODO Auto-generated method stub
		return dao.retrieveDetails(traineeId);
	}

	@Override
	public ArrayList<Trainee> retrieveAllDetails() {
		// TODO Auto-generated method stub
		return dao.retrieveAllDetails();
	}

}
