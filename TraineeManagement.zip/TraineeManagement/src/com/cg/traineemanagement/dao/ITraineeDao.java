package com.cg.traineemanagement.dao;

import java.util.ArrayList;

import com.cg.traineemanagement.bean.Trainee;
import com.cg.traineemanagement.bean.UserLogin;

public interface ITraineeDao {
	public boolean login(UserLogin login);
	
	public void addDetails(Trainee trainee);
	
	public ArrayList<Trainee> getDeleteDetails(Integer traineeId);
	
	public void deleteTrainee(Trainee trainee);
	
	public ArrayList<Trainee> getmodifyDetails(Integer traineeId);
	
	public void modifyTrainee(Trainee trainee);
	
	public ArrayList<Trainee> retrieveDetails(Integer traineeId);
	
	public ArrayList<Trainee> retrieveAllDetails();
}
