package com.cg.traineemanagement.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.traineemanagement.bean.Trainee;
import com.cg.traineemanagement.bean.UserLogin;

@Repository
@Transactional
public class TraineeDaoImpl implements ITraineeDao{
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public boolean login(UserLogin login) {
		boolean result=false;
		Query query=entityManager.createNamedQuery("login");
		ArrayList<UserLogin> list=(ArrayList<UserLogin>) query.setParameter("uname",login.getUserName()).setParameter("pass", login.getPassWord()).getResultList();
		if(!list.isEmpty()){
			result=true;
		}
		return result;
	}

	@Override
	public void addDetails(Trainee trainee) {
		entityManager.persist(trainee);
		entityManager.flush();
	}

	@Override
	public ArrayList<Trainee> getDeleteDetails(Integer traineeId) {
		Query query=entityManager.createNamedQuery("getdelete");
		ArrayList<Trainee> list=(ArrayList<Trainee>) query.setParameter("id", traineeId).getResultList();
		return list;
	}

	@Override
	public void deleteTrainee(Trainee trainee) {
		Trainee t=entityManager.find(Trainee.class, trainee.getTraineeId());
		entityManager.remove(t);
	}

	@Override
	public ArrayList<Trainee> getmodifyDetails(Integer traineeId) {
		Query query=entityManager.createNamedQuery("modify");
		ArrayList<Trainee> list=(ArrayList<Trainee>) query.setParameter("id", traineeId).getResultList();
		return list;
	}

	@Override
	public void modifyTrainee(Trainee trainee) {
		entityManager.merge(trainee);
	}

	@Override
	public ArrayList<Trainee> retrieveDetails(Integer traineeId) {
		// TODO Auto-generated method stub
		Query query=entityManager.createNamedQuery("retrieve");
		ArrayList<Trainee> list=(ArrayList<Trainee>) query.setParameter("id", traineeId).getResultList();
		return list;
	}

	@Override
	public ArrayList<Trainee> retrieveAllDetails() {
		// TODO Auto-generated method stub
		Query query=entityManager.createNamedQuery("retrieveall");
		ArrayList<Trainee> list=(ArrayList<Trainee>) query.getResultList();
		return list;
	}

}
