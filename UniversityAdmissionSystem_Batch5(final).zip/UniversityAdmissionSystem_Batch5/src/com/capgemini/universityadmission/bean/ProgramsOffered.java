package com.capgemini.universityadmission.bean;

import java.io.Serializable;

public class ProgramsOffered implements Serializable {

	private static final long serialVersionUID = 1L;

	private String programName;
	private String programDescription;
	private String applicantEligibility;
	private Integer programDuration;
	private String degreeCertOffered;

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getProgramDescription() {
		return programDescription;
	}

	public void setProgramDescription(String programDescription) {
		this.programDescription = programDescription;
	}

	public String getApplicantEligibility() {
		return applicantEligibility;
	}

	public void setApplicantEligibility(String applicantEligibility) {
		this.applicantEligibility = applicantEligibility;
	}

	public Integer getProgramDuration() {
		return programDuration;
	}

	public void setProgramDuration(Integer programDuration) {
		this.programDuration = programDuration;
	}

	public String getDegreeCertOffered() {
		return degreeCertOffered;
	}

	public void setDegreeCertOffered(String degreeCertOffered) {
		this.degreeCertOffered = degreeCertOffered;
	}

}
