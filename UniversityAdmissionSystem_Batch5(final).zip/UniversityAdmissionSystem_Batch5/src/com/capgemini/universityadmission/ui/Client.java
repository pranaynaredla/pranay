package com.capgemini.universityadmission.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.universityadmission.bean.Application;
import com.capgemini.universityadmission.bean.Participants;
import com.capgemini.universityadmission.bean.ProgramsOffered;
import com.capgemini.universityadmission.bean.ProgramsScheduled;
import com.capgemini.universityadmission.exception.IExceptionMessages;
import com.capgemini.universityadmission.exception.UASException;
import com.capgemini.universityadmission.service.IUniversityService;
import com.capgemini.universityadmission.service.UniversityServiceImpl;
import com.capgemini.universityadmission.service.Validation;

public class Client {
	public static void main(String[] args) {
		boolean valid = true;
		try {
			System.out
					.println("****************************************************************************************************************");
			System.out
					.println("*                                   UNIVERSITY ADMISSION SYSTEM                                                *");
			System.out
					.println("****************************************************************************************************************");
			IUniversityService service = new UniversityServiceImpl();
			int choice = -1;
			System.out.println();
			System.out
					.println("------------------------------------------------------------------------------------------------------------------");
			System.out.println();
			System.out
					.println("*****************************************************************************************************************");
			System.out
					.println("*                                         Programs Offered                                                      *");
			System.out
					.println("*****************************************************************************************************************");
			ArrayList<ProgramsOffered> list = new ArrayList<>();
			// Retrieving all the programs offered by the University
			list = service.viewAllPrograms();
			if (list.isEmpty()) {
				throw new UASException(IExceptionMessages.MESSAGE5);
			}
			System.out.printf("%10s %20s %25s %10s %20s", "PROGRAM_NAME",
					"PROGRAM_DESCRIPTION", "APPLICANT_ELIGIBILITY", "DURATION",
					"DEGREE_CERT_OFFERED");
			System.out.println();
			for (ProgramsOffered po : list) {
				System.out.format("%10s %20s %27s %10s %20s",
						po.getProgramName(), po.getProgramDescription(),
						po.getApplicantEligibility(), po.getProgramDuration(),
						po.getDegreeCertOffered());
				System.out.println();
			}
			System.out
					.println("----------------------------------------------------------------------------------------------------------");
			do {
				System.out.println();
				System.out.println("Enter your Choice");
				System.out
						.println("1.View Scheduled Programs\n2.Register to a Program\n3.Application Status\n4.Login as Admin or Mac\n5.Exit");
				Scanner scanner = new Scanner(System.in);
				try{
					choice = scanner.nextInt();
				}catch(InputMismatchException e)
				{
					throw new UASException(IExceptionMessages.MESSAGE19);
				}
				switch (choice) {
				case 1:
					System.out.println();
					System.out
							.println("********************************************************************************************************************");
					System.out
							.println("*                                               Scheduled Programs                                                 *");
					System.out
							.println("********************************************************************************************************************");
					ArrayList<ProgramsScheduled> list1 = new ArrayList<>();
					// Retrieving all the programs scheduled by the University
					list1 = service.viewScheduledPrograms();
					if (list1.isEmpty()) {
						throw new UASException(IExceptionMessages.MESSAGE6);
					}
					System.out.printf("%15s %10s %10s %17s %19s %12s",
							"SCHEDULE_PROG_ID", "PROGRAM_NAME", "LOCATION",
							"START_DATE", "END_DATE", "SESSIONS_PER_WEEK");
					System.out.println();
					for (ProgramsScheduled ps : list1) {
						System.out.format("%15s %10s %10s %20s %20s %10s",
								ps.getScheduledProgramId(),
								ps.getProgramName(), ps.getLocation(),
								ps.getStartDate(), ps.getEndDate(),
								ps.getSessionsPerWeek());
						System.out.println();
					}
					System.out
							.println("---------------------------------------------------------------------------------------------------------------------");
					System.out.println();
					break;
				case 2:
					System.out.println();
					System.out
							.println("********************************************************************************************************************");
					System.out
							.println("*                                                 Registration Form                                                *");
					System.out
							.println("********************************************************************************************************************");
					Scanner scanner2 = new Scanner(System.in);
					Application application = new Application();

					System.out.println("Enter Full Name");
					do {
						String fullName = scanner2.nextLine();
						valid = Validation.isValidFullName(fullName);
						if (valid)
							application.setFullName(fullName);
						else
							System.err
									.println("Please enter valid Full Name..It should not contain any digits");
					} while (valid != true);
					System.out.println("Enter Date Of Birth(dd/MM/yyyy)");
					do {
						String dateOfBirth = scanner2.nextLine();
						LocalDate ld;
						valid = Validation.isValidDateOfBirth(dateOfBirth);
						if (valid) {
							DateTimeFormatter formatter = DateTimeFormatter
									.ofPattern("dd/MM/yyyy");
							ld = LocalDate.parse(dateOfBirth, formatter);
							application.setDateOfBirth(ld);
						} else
							System.err
									.println("Please enter date of birth in the format(dd/MM/yyyy) and Birth year should be between 1980 and 1999");
					} while (valid != true);
					System.out
							.println("Enter highest Qualification(B.Tech/M.Tech/MCA)");
					do {
						String highestQualification = scanner2.nextLine();
						valid = Validation
								.isValidHighestQualification(highestQualification);
						if (valid)
							application
									.setHighestQualification(highestQualification);
						else
							System.err
									.println("Please enter valid Qualification (B.Tech/M.Tech/MCA)");
					} while (valid != true);

					System.out.println("Enter Goals");
					do {
						String goals = scanner2.nextLine();
						valid = Validation.isValidGoals(goals);
						if (valid)
							application.setGoals(goals);
						else
							System.err
									.println("Goals should not exceed 20 characters");
					} while (valid != true);
					System.out.println("Enter Email ID");
					do {
						String emailId = scanner2.nextLine();
						valid = Validation.isValidEmail(emailId);
						if (valid)
							application.setEmailId(emailId);
						else
							System.err.println("Please enter valid email Id..");
					} while (valid != true);
					System.out.println("Enter Program Scheduled ID");
					do {
						String scheduledId = scanner2.nextLine();
						valid = Validation.isValidScheduledId(scheduledId);
						if (valid)
							application.setScheduledProgramId(scheduledId);
						else
							System.err
									.println("Please enter valid Scheduled ID");
					} while (valid != true);
					System.out.println("Enter Marks Obtained");
					do {
						Integer marksObtained = 0;
						try {
							marksObtained = scanner2.nextInt();
						} catch (InputMismatchException e) {
							throw new UASException(IExceptionMessages.MESSAGE19);
						}
						valid = Validation.isValidMarks(marksObtained);
						if (valid)
							application.setMarksObtained(marksObtained);
						else
							System.err
									.println("Please enter valid marks.. They should not be negative and more than 100");
					} while (valid != true);
					System.out.println();
					// Stores applicant details in database and returns
					// applicant id to applicant

					int regApplicantId = service.addApplicantDetails(application);
					if (regApplicantId != 0) {
						System.out.println("REGISTERED SUCCESSFULLY....!!!");
						System.out.println();
						System.out.println("Your applicantId is ::"
								+ regApplicantId);
					} else {
						System.out.println();
						System.out.println("NOT REGISTERED SUCCESSFULLY..!!!");
					}
					break;
				case 3:
					System.out.println();
					System.out.println("Please enter your ApplicantID");
					do {
						Scanner scanner1 = new Scanner(System.in);
						Integer applicantId = 0;
						try {
							applicantId = scanner1.nextInt();
						} catch (InputMismatchException e) {
							throw new UASException(IExceptionMessages.MESSAGE19);
						}
						valid = Validation.isValidApplicantId(applicantId);
						if (valid) {
							System.out.println();
							Application application1 = new Application();
							application1 = service.applicantStatus(applicantId);
							if (application1.getStatus().equalsIgnoreCase(
									"accepted")) {
								System.out
										.println("Your application status is "
												+ application1.getStatus()
														.toUpperCase()
												+ " and your interview is scheduled on "
												+ application1
														.getDateOfInterview());
							} else {
								System.out
										.println("Your application status is :: "
												+ application1.getStatus()
														.toUpperCase());
							}
						} else
							System.err
									.println("Please enter valid Applicant ID");
					} while (valid != true);
					break;
				case 4:
					Scanner scanner3 = new Scanner(System.in);
					String role = null;
					Integer ch = -1;
					loginBlock: do {
						Scanner scanner4 = new Scanner(System.in);
						System.out
								.println("1.Login as mac\n2.Login as admin\n3.Exit");
						System.out.println("Enter your choice");
						try{
							ch = scanner4.nextInt();
						}catch(InputMismatchException e)
						{
							throw new UASException(IExceptionMessages.MESSAGE19);
						}
						
						System.out.println();
						switch (ch) {
						case 1:
							System.out.println("Enter UserName");
							String userName = scanner3.next();
							System.out.println("Enter Password");
							String password = scanner3.next();
							System.out.println("Choose your role(mac/admin)");
							role = scanner3.next().toLowerCase();
							// To authenticate admin or mac credentials
							boolean authorised = service.adminLogin(userName,
									password, role);
							if (authorised) {
								macblock: do {
									System.out
											.println("1.Filter and update the status of the applicants");
									System.out
											.println("2.View Applicant Details\n3.Confirm or Reject the Participants");
									System.out.println("4.Add Participants  ");
									System.out.println("5.View participants");

									System.out.println("6.Exit");
									System.out.println("Choose your choice");
									ch = scanner3.nextInt();
									System.out.println();
									switch (ch) {
									case 1:
										System.out
												.println("Enter program name");
										String progName = null;
										do {
											Scanner sc = new Scanner(System.in);
											progName = sc.next();
											valid = Validation
													.isValidProgramName(progName);
											if (valid) {
												System.out.printf(
														"%15s %20s %20s %20s",
														"APPLICANT_ID",
														"FULL_NAME",
														"MARKS_OBTAINED",
														"QUALIFICATION");
												System.out.println();
												ArrayList<Application> list3 = new ArrayList<>();
												// Retrieving all the applicants
												// based
												// on the program name given by
												// mac
												list3 = service
														.filterApplicantsByProgramName(progName);
												if (list3.isEmpty()) {
													throw new UASException(
															IExceptionMessages.MESSAGE10);
												}
												for (Application a : list3) {
													System.out
															.format("%15s %20s %20s %20s",
																	a.getApplicantId(),
																	a.getFullName(),
																	a.getMarksObtained(),
																	a.getHighestQualification());
													System.out.println();
												}
												System.out.println();
												for (Application b : list3) {
													if (service
															.updateStatus(
																	b.getApplicantId(),
																	b.getMarksObtained()) == 1) {
														System.out
																.println(b
																		.getApplicantId()
																		+ " IS UPDATED");
													} else {
														System.out
																.println(b
																		.getApplicantId()
																		+ " IS NOT UPDATED");
													}
												}
											} else {
												System.err
														.println("Please enter valid program name..Its limit is 5 characters");
											}
										} while (valid != true);
										System.out.println();
										break;
									case 2:
										ArrayList<Application> arrayList=service.viewApplicantDetails();
										System.out.printf(
												"%15s %20s %20s %20s",
												"APPLICANT_ID", "FULL_NAME",
												"MARKS_OBTAINED",
												"HIGHEST_QUALIFICATION");
										for (Application a : arrayList) {
											System.out.println();
											System.out.format(
													"%15s %20s %20s %20s",
													a.getApplicantId(),
													a.getFullName(),
													a.getMarksObtained(),
													a.getHighestQualification());
											System.out.println();
										}
										break;
									case 3:
										System.out.println("Enter Applicant ID:");
										do {
											Scanner scanner6 = new Scanner(
													System.in);
											Integer applicantId = 0;
											String status = null;
											try {
												Scanner scanner7 = new Scanner(
														System.in);
												applicantId = scanner7
														.nextInt();
											} catch (InputMismatchException e) {
												throw new UASException(
														IExceptionMessages.MESSAGE19);
											}
											valid = Validation
													.isValidApplicantId(applicantId);
											if (valid) {

												System.out
														.println("Enter the status of the applicant(confirmed/rejected)");
												status = scanner6.nextLine();
												if (status != null
														&& status
																.equals("confirmed")
														|| status
																.equals("rejected")) {
													Integer result = service
															.confirmParticipants(
																	applicantId,
																	status);
													System.out.println();
													if (result > 0)
														System.out
																.println("PARTICIPANT STATUS UPDATED AS REJECTED OR CONFIRMED");
													else
														System.out
																.println("NO PARTICIPANTS TO UPDATE");
													System.out.println();
												} else
													System.err
															.println("Please enter valid status");
											} else
												System.err
														.println("Please enter valid applicant Id");
										} while (valid != true);
										break;
									case 4:
										System.out.println();
										Application application2 = new Application();
										// Adding the participants to
										// participants table based on their
										// status
										if (service
												.addParticipants(application2) == 1) {
											System.out
													.println("PARTICIPANTS ADDED...!!");
										} else {
											/*
											 * throw new UASException(
											 * IExceptionMessages.MESSAGE14);
											 */
											System.out
													.println("NO PARTICIPANT TO GET ADDED...!!");
										}

										break;
									case 5:
										ArrayList<Participants> list2 = new ArrayList<>();
										// Retrieving all the participants
										// registered for the scheduled program
										list2 = service.retrieveParticipants();
										if (list2.isEmpty()) {
											throw new UASException(
													IExceptionMessages.MESSAGE17);
										}
										System.out.printf(
												"%15s %20s %20s %20s",
												"ROLL_NO", "EMAIL_ID",
												"APPLICANT_ID",
												"SCHEDULED_PROGRAM_ID");
										for (Participants p : list2) {
											System.out.println();
											System.out.format(
													"%15s %20s %20s %20s",
													p.getRollNo(),
													p.getEmailId(),
													p.getApplicantId(),
													p.getScheduledProgramId());
											System.out.println();
										}
										System.out.println();
										break;
									case 6:
										break macblock;
									}
								} while (ch != 0);
							} else {
								System.out.println();
								System.err.println("NOT AUTHORISED");
								System.out.println();
							}
							break;
						case 2:
							System.out.println("Enter UserName");
							String userName1 = scanner3.next();
							System.out.println("Enter Password");
							String password2 = scanner3.next();
							System.out.println("Choose your role(mac/admin)");
							role = scanner3.next().toLowerCase();
							// To authenticate admin or mac credentials
							boolean authorised1 = service.adminLogin(userName1,
									password2, role);
							if (authorised1) {
								adminblock: do {
									System.out
											.println("1.Insert Programs Scheduled\n2.Insert Programs Offered");
									System.out
											.println("3.Delete Programs Scheduled\n4.Delete Expired Programs\n5.Delete Programs Offered\n6.View Participants\n7.exit");
									System.out.println("Choose your choice");
									try{
										ch = scanner3.nextInt();
									}catch(InputMismatchException e){
										throw new UASException(IExceptionMessages.MESSAGE19);
									}
								
									switch (ch) {
									case 1:
										ProgramsScheduled programsScheduled = new ProgramsScheduled();
										System.out.println("Enter program id");
										do {
											String scheduledProgramId = scanner3
													.next();
											valid = Validation
													.isValidProgramId(scheduledProgramId);
											if (valid)
												programsScheduled
														.setScheduledProgramId(scheduledProgramId);
											else
												System.err
														.println("Please enter valid Program Id.. Its limit is 5 characters");
										} while (valid != true);
										System.out
												.println("Enter program name");
										do {
											String programName = scanner3
													.next();
											valid = Validation
													.isValidProgramName(programName);
											if (valid)
												programsScheduled
														.setProgramName(programName);
											else
												System.err
														.println("Please enter valid program name..Its limit is 5 characters");
										} while (valid != true);
										System.out.println("Enter location");
										do {
											String location = scanner3.next();
											valid = Validation
													.isValidLocationName(location);
											if (valid)
												programsScheduled
														.setLocation(location);
											else
												System.err
														.println("Please enter valid location.. It should not contain digits");
										} while (valid != true);
										System.out.println("Enter start date");
										do {
											String sdate = scanner3.next();
											LocalDate startDate = null;
											valid = Validation
													.isValidDateFormat(sdate);
											if (valid) {
												DateTimeFormatter formatter1 = DateTimeFormatter
														.ofPattern("dd/MM/yyyy");
												startDate = LocalDate.parse(
														sdate, formatter1);
												programsScheduled
														.setStartDate(startDate);
											} else {
												System.err
														.println("Please enter valid start date of format (dd/MM/yyyy)");
											}
										} while (valid != true);
										System.out.println("Enter end date");
										do {
											String edate = scanner3.next();
											LocalDate endDate = null;
											valid = Validation
													.isValidDateFormat(edate);
											if (valid) {
												DateTimeFormatter formatter2 = DateTimeFormatter
														.ofPattern("dd/MM/yyyy");
												endDate = LocalDate.parse(
														edate, formatter2);
												programsScheduled
														.setEndDate(endDate);
											} else
												System.err
														.println("Please enter valid end date of format (dd/MM/yyyy)");
										} while (valid != true);
										System.out
												.println("Enter sessions per week");
										Integer sessionsPerWeek = 0;
										try {
											sessionsPerWeek = scanner3
													.nextInt();
										} catch (InputMismatchException e) {
											throw new UASException(
													IExceptionMessages.MESSAGE19);
										}
										if (sessionsPerWeek > 0)
											programsScheduled
													.setSessionsPerWeek(sessionsPerWeek);
										else
											System.err
													.println("Please enter valid value..It should not be negative or a string");
										// Admin inserts new programs into the
										// database
										System.out.println();
										if (service
												.insertProgramScheduled(programsScheduled) == 1)
											System.out
													.println("PROGRAM ADDED SUCCESSFULLY...!!");
										else
											System.out
													.println("PROGRAM NOT ADDED....!! ");
										System.out.println();
										break;
									case 2:
										ProgramsOffered programsOffered = new ProgramsOffered();
										Scanner scanner5 = new Scanner(
												System.in);
										System.out
												.println("Enter program Name");
										do {
											String programName1 = scanner5
													.nextLine();
											valid = Validation
													.isValidProgramName(programName1);
											if (valid)
												programsOffered
														.setProgramName(programName1);
											else
												System.err
														.println("Please enter valid program Name..It's limit is 5 characters");
										} while (valid != true);
										System.out
												.println("Enter Program Description");
										do {
											String programDescription = scanner5
													.nextLine();
											valid = Validation
													.isValidDescription(programDescription);
											if (valid)
												programsOffered
														.setProgramDescription(programDescription);
											else
												System.err
														.println("Program Description limits to 20 characters.. Please enter less than 20 characters");
										} while (valid != true);
										System.out
												.println("Enter applicant eligibility");
										String applicantEligibility = scanner5
												.nextLine();
										programsOffered
												.setApplicantEligibility(applicantEligibility);
										System.out
												.println("Enter degree certificate offered");
										do {
											String degreeCertOffered = scanner5
													.nextLine();
											valid = Validation
													.isValidCertName(degreeCertOffered);
											if (valid)
												programsOffered
														.setDegreeCertOffered(degreeCertOffered);
											else
												System.err
														.println("It's size limits to 10 characters");
										} while (valid != true);
										System.out
												.println("Enter duration of the course");
										Integer programDuration = 0;
										try {
											programDuration = scanner5
													.nextInt();
										} catch (InputMismatchException e) {
											throw new UASException(
													IExceptionMessages.MESSAGE19);
										}
										programsOffered
												.setProgramDuration(programDuration);

									case 3:
										ProgramsScheduled programsScheduled2 = new ProgramsScheduled();
										System.out.println("Enter program id");
										String scheduledProgramId = null;
										do {
											scheduledProgramId = scanner3
													.next();
											valid = Validation
													.isValidScheduledId(scheduledProgramId);
											if (valid)
												programsScheduled2
														.setScheduledProgramId(scheduledProgramId);
											else
												System.err
														.println("Please enter valid Scheduled Program Id.. ");
										} while (valid != true);
										// Admin removes scheduled programs from
										// the database
										System.out.println();
										if (service
												.removeProgramsScheduled(scheduledProgramId) == 1) {
											System.out
													.println("PROGRAM REMOVED SUCCESSFULLY..!!");
										} else {
											System.out
													.println("PROGRAM NOT REMOVED..!!");
										}
										System.out.println();
										break;
									case 4:
										Integer index = service
												.deleteProgramsExpired();
										System.out.println();
										if (index > 0) {
											System.out
													.println("PROGRAMS ARE UPDATED");
										} else {
											System.out
													.println("NO SCHEDULE PROGRAMS TO UPDATE");
										}
										System.out.println();
										break;
									case 5:
										System.out
												.println("Enter the program name to be deleted");
										Scanner scanner6 = new Scanner(
												System.in);
										String programName1 = null;
										Integer result = 0;
										do {
											programName1 = scanner6.next();
											valid = Validation
													.isValidProgramName(programName1);
											if (valid) {
												result = service
														.deleteProgramsOffered(programName1);
												if (result == 1) {
													System.out
															.println("PROGRAMS OFFERED DELETED SUCCESSFULLY");
												} else {
													System.out
															.println("PROGRAMS OFFERED NOT DELETED SUCCESSFULLY");
												}
											} else
												System.err
														.println("Please enter valid Program Name");
										} while (valid != true);

									case 6:
										ArrayList<Participants> list2 = new ArrayList<>();
										// Retrieving all the participants
										// registered for the scheduled program
										list2 = service.retrieveParticipants();
										if (list2.isEmpty()) {
											throw new UASException(
													IExceptionMessages.MESSAGE17);
										}
										System.out.printf(
												"%15s %20s %20s %20s",
												"ROLL_NO", "EMAIL_ID",
												"APPLICANT_ID",
												"SCHEDULED_PROGRAM_ID");
										for (Participants p : list2) {
											System.out.println();
											System.out.format(
													"%15s %20s %20s %20s",
													p.getRollNo(),
													p.getEmailId(),
													p.getApplicantId(),
													p.getScheduledProgramId());
											System.out.println();
										}
										break;
									case 7:
										break adminblock;
									}

								} while (ch != 0);
							} else {
								System.out.println();
								System.err.println("NOT AUTHORISED");
								System.out.println();
							}
							break;
						case 3:
							break loginBlock;
						}
					} while (role != null);
					break;
				case 5:
					System.out.println("THANK YOU...!!");
					System.exit(0);
					break;
				}
			} while (choice != 0);
		} catch (UASException e) {
			System.out.println(e.getMessage());
		}
	}
}
