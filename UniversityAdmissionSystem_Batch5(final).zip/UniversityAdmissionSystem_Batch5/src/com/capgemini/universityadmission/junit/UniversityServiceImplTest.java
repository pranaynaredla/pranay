package com.capgemini.universityadmission.junit;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import org.junit.Test;

import com.capgemini.universityadmission.bean.Application;
import com.capgemini.universityadmission.bean.Participants;
import com.capgemini.universityadmission.bean.ProgramsOffered;
import com.capgemini.universityadmission.bean.ProgramsScheduled;
import com.capgemini.universityadmission.exception.UASException;
import com.capgemini.universityadmission.service.IUniversityService;
import com.capgemini.universityadmission.service.UniversityServiceImpl;

public class UniversityServiceImplTest {

	public UniversityServiceImplTest() {
		super();
	}

	@Test
	public void testProgramOffered() throws UASException{
		IUniversityService service=new UniversityServiceImpl();
		ArrayList<ProgramsOffered> list=service.viewAllPrograms();
		assertEquals("ML", list.get(0).getProgramName());
	}	
	
	@Test
	public void testProgramScheduled() throws UASException{
		IUniversityService service=new UniversityServiceImpl();
		ArrayList<ProgramsScheduled> list=service.viewScheduledPrograms();
		assertEquals("104", list.get(3).getScheduledProgramId());
		assertEquals("Pune", list.get(3).getLocation());
	}
	
	/*@Test
	public void testApplicantDetails() throws UASException {
		IUniversityService service = new UniversityServiceImpl();
		Application application = new Application();
		application.setFullName("Mark Goyal");
		String dateOfBirth = "25/02/1997";
		LocalDate ld;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		ld = LocalDate.parse(dateOfBirth, formatter);
		application.setDateOfBirth(ld);
		application.setHighestQualification("B.Tech");
		application.setMarksObtained(72);
		application.setGoals("SWE");
		application.setEmailId("pn@g.com");
		application.setScheduledProgramId("102");
		application.setStatus("applied");
		int i = service.applicantDetails(application);
		assertEquals(1092, i);
	}*/
	
	
	/* * error@Test public void testadminLogin() throws UASException{
	 * IUniversityService service = new UniversityServiceImpl(); Application
	 * application=new Application(); String userName="JAVA";
	 * ArrayList<Application> list = service.adminLogin(userName, password,
	 * role) assertEquals(1041, list);
	 * 
	 * }*/
	 
	
	@Test
	public void testAdminLogin() throws UASException{
		IUniversityService service = new UniversityServiceImpl();
		String userName="admin";
		String password ="admin";
		String role = "admin";
		boolean result = service.adminLogin(userName, password, role);
		assertEquals(true, result);
	}
	
	@Test
	public void testApplicantStatus() throws UASException{
		IUniversityService service = new UniversityServiceImpl();
		Integer id = 1084;
		Application application = service.applicantStatus(id);
		assertEquals("accepted", application.getStatus());
	}
	
	@Test
	public void testUpdateStatus() throws UASException{
		IUniversityService service = new UniversityServiceImpl();
		Integer applicantId=1085;
		Integer marksObtained=70;
		int result = service.updateStatus(applicantId, marksObtained);
		assertEquals(1, result);
	}
	
	@Test
	public void testAddParticipants() throws UASException{
		IUniversityService service = new UniversityServiceImpl();
		Application application=new Application();
		int result=service.addParticipants(application);
		assertEquals(0, result);
	}

	/*@Test
	public void testDeletePrograms() throws UASException{
		//exception
		IUniversityService service = new UniversityServiceImpl();
		int result = service.deletePrograms();
		assertEquals(0, result);
	}*/

	/*@Test
	public void testInsertProgram() throws UASException{
		IUniversityService service = new UniversityServiceImpl();
		
		String sd = "28/04/2017";
		LocalDate startDate;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		startDate = LocalDate.parse(sd, formatter);
		
		String ed = "16/08/2017";
		LocalDate endDate;
		endDate = LocalDate.parse(ed, formatter);
		
		ProgramsScheduled programsScheduled = new ProgramsScheduled();
		programsScheduled.setScheduledProgramId("123");
		programsScheduled.setProgramName("JAVA");
		programsScheduled.setLocation("Chennai");
		programsScheduled.setStartDate(startDate);
		programsScheduled.setEndDate(endDate);
		programsScheduled.setSessionsPerWeek(4);
		int result = service.insertProgramScheduled(programsScheduled);
		assertEquals(1, result);
	}*/
	
	/*@Test
	public void testRemoveProgramsScheduled() throws UASException{
		IUniversityService service = new UniversityServiceImpl();
		String scheduledId = "123";
		int result = service.removeProgramsScheduled(scheduledId);
		assertEquals(0, result);	
	}*/
	
	@Test
	public void testViewAllPrograms() throws UASException{
		IUniversityService service = new UniversityServiceImpl();
		ArrayList<ProgramsOffered> list = service.viewAllPrograms();
		assertEquals("AI", list.get(2).getProgramName());
	}
	
	@Test
	public void testRetrieveParticipants() throws UASException{
		IUniversityService service = new UniversityServiceImpl();
		ArrayList<Participants> list = service.retrieveParticipants();
		assertEquals("123", list.get(0).getRollNo());
	}

}
