package com.capgemini.universityadmission.exception;

public interface IExceptionMessages {

	public static final String MESSAGE1 = "Property File not found...!";
	public static final String MESSAGE2 = "Driver Class not found..!";
	public static final String MESSAGE3 = "Problem in reading property..!";
	public static final String MESSAGE4 = "Problem in obtaining connection to data..!!";
	public static final String MESSAGE5 = "Programs offered are not available..!";
	public static final String MESSAGE6 = "Scheduled Programs are not available";
	public static final String MESSAGE7 = "Applicants details cannot be inserted";
	public static final String MESSAGE8 = "Applicant ID Sequence cannot be generated";
	public static final String MESSAGE9 = "Login credentials are not found..!";
	public static final String MESSAGE10 = "The applicants details cannot be generated for the given program name..!";
	public static final String MESSAGE11 = "Cannot retrieve the status of the applicants..!";
	public static final String MESSAGE12 = "Application Status cannot be updated..!";
	public static final String MESSAGE13 = "The applicants details cannot be generated..!";
	public static final String MESSAGE14 = "Participants details cannot be added..!";
	public static final String MESSAGE15 = "The programs scheduled cannot be deleted..!";
	public static final String MESSAGE16 = "The entered details cannot be inserted into programs_scheduled...!";
	public static final String MESSAGE17 = "The participants details cannot be generated..!";
	public static final String MESSAGE18 = "The program scheduled cannot be deleted for the given program ID..!";
	public static final String MESSAGE19 = "Only digits are allowed..!";

}
