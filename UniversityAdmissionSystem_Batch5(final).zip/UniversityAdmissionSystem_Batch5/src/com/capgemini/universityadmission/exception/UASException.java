package com.capgemini.universityadmission.exception;

public class UASException extends Exception implements IExceptionMessages{

	private static final long serialVersionUID = 1L;

	public UASException() {
	}

	public UASException(String arg0) {
		super(arg0);
	}

}
