package com.capgemini.universityadmission.dao;

import java.util.ArrayList;

import com.capgemini.universityadmission.bean.Application;
import com.capgemini.universityadmission.bean.Participants;
import com.capgemini.universityadmission.bean.ProgramsOffered;
import com.capgemini.universityadmission.bean.ProgramsScheduled;
import com.capgemini.universityadmission.exception.UASException;

public interface IUniversityDao {
	public ArrayList<ProgramsOffered> viewAllPrograms() throws UASException;

	public ArrayList<ProgramsScheduled> viewScheduledPrograms()
			throws UASException;

	public Integer addApplicantDetails(Application application)
			throws UASException;

	public boolean adminLogin(String userName, String password, String role)
			throws UASException;

	public Application applicantStatus(Integer id) throws UASException;

	public Integer addParticipants(Application application) throws UASException;

	public ArrayList<Application> filterApplicantsByProgramName(String progName)
			throws UASException;

	public Integer deleteProgramsExpired() throws UASException;

	public Integer insertProgram(ProgramsScheduled programsScheduled)
			throws UASException;

	public Integer updateStatus(Integer applicantId, Integer marksObtained)
			throws UASException;

	public ArrayList<Participants> retrieveParticipants() throws UASException;

	public Integer removeProgramsScheduled(String scheduledId)
			throws UASException;

	public boolean checkApplicantId(Integer applicantId) throws UASException;

	public boolean checkScheduledId(String scheduledId) throws UASException;
	
	public Integer confirmParticipants(Integer applicantId,String status) throws UASException;

	public Integer addProgramsOffered(ProgramsOffered programsOffered)
			throws UASException;

	public Integer deleteProgramsOffered(String programName1) throws UASException;
	
	public ArrayList<Application> viewApplicantDetails() throws UASException;

}
