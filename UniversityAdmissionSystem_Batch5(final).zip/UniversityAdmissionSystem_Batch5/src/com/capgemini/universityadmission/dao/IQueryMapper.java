package com.capgemini.universityadmission.dao;

public interface IQueryMapper {

	public static final	String QUERY1 = "SELECT program_name,description,applicant_eligibility,duration,degree_certificate_offered FROM programs_offered";
	public static final	String QUERY2 = "SELECT scheduled_program_id,program_name,location,start_date,end_date,sessions_per_week FROM programs_scheduled";
	public static final	String QUERY3 = "INSERT INTO application VALUES(applicant_id_seq.NEXTVAL,?,?,?,?,?,?,?,?,SYSDATE)";
	public static final	String QUERY4 = "SELECT login_id,password,role FROM user_details";
	public static final	String QUERY5 = "SELECT a.applicant_id,a.full_name,a.marks_obtained,a.highest_qualification FROM application a JOIN programs_scheduled p ON a.scheduled_program_id=p.scheduled_program_id WHERE p.program_name=?";
	public static final	String QUERY6 = "SELECT status,date_of_interview FROM application WHERE applicant_id=?";
	public static final	String QUERY7 = "UPDATE application SET status=? ,date_of_interview=date_of_interview+? WHERE applicant_id=?";
	public static final	String QUERY8 = "INSERT INTO participant VALUES(roll_no_seq.NEXTVAL,?,?,?)";
	public static final	String QUERY9 = "SELECT email_id,applicant_id,scheduled_program_id FROM application WHERE status=? AND applicant_id NOT IN(SELECT applicant_id FROM participant)";
	public static final	String QUERY10 = "DELETE FROM programs_scheduled WHERE SYSDATE>end_date";
	public static final	String QUERY11 = "INSERT INTO programs_scheduled VALUES(?,?,?,?,?,?)";
	public static final	String QUERY12 = "UPDATE application SET status=? WHERE applicant_id=?";
	public static final	String QUERY13 = "SELECT DISTINCT applicant_id,roll_no,email_id,scheduled_program_id FROM participant";
	public static final	String QUERY14 = "DELETE FROM programs_scheduled WHERE scheduled_program_id=?";
	public static final	String QUERY15 = "SELECT applicant_id_seq.CURRVAL FROM dual";
	public static final	String QUERY16 = "SELECT scheduled_program_id from programs_scheduled";
	public static final	String QUERY17 = "SELECT applicant_id from application";
	public static final String QUERY18 = "UPDATE application SET status=? WHERE status=? AND applicant_id=?";
	public static final String QUERY19 = "DELETE FROM programs_offered where program_name = ?";
	public static final String QUERY20 = "SELECT applicant_id,full_name,marks_obtained,highest_qualification FROM application WHERE status='accepted'";

}
