package com.capgemini.universityadmission.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.universityadmission.dao.IUniversityDao;
import com.capgemini.universityadmission.dao.UniversityDaoImpl;
import com.capgemini.universityadmission.exception.UASException;

public class Validation {

	public static boolean isValidFullName(String fullName) {

		String regx = "^[A-Za-z ]{3,20}$";
		Pattern pattern = Pattern.compile(regx, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(fullName);
		return matcher.find();

	}

	public static boolean isValidDateOfBirth(String date) {
		String regx = "^(3[01]|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/19[89][0-9]{1}$";
		Pattern pattern = Pattern.compile(regx, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(date);
		return matcher.find();

	}
	
	public static boolean isValidDateFormat(String date) {
		String regx = "^(3[01]|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/20[0-9][0-9]$";
		Pattern pattern = Pattern.compile(regx, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(date);
		return matcher.find();

	}

	public static boolean isValidHighestQualification(String txt) {
		if (txt.equalsIgnoreCase("B.Tech") || txt.equalsIgnoreCase("M.Tech")
				|| txt.equalsIgnoreCase("MCA") ||txt.equalsIgnoreCase("MBA")) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean isValidEmail(String email) {
		String emailRegex="^[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,20}$";

		Pattern pattern = Pattern.compile(emailRegex);
		if (email == null)
			return false;
		return pattern.matcher(email).matches();
	}

	public static boolean isValidMarks(Integer marks) {
		if (marks > 0 && marks <= 100)
			return true;
		else
			return false;
	}

	public static boolean isValidLocationName(String location) {

		String regx = "^[A-Za-z ]{3,10}$";
		Pattern pattern = Pattern.compile(regx, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(location);
		return matcher.find();

	}

	public static boolean isValidApplicantId(Integer applicantId)
			throws UASException {
		IUniversityDao universityDao = new UniversityDaoImpl();
		boolean result = universityDao.checkApplicantId(applicantId);
		return result;
	}

	public static boolean isValidScheduledId(String scheduledId)
			throws UASException {
		IUniversityDao universityDao = new UniversityDaoImpl();
		boolean result = universityDao.checkScheduledId(scheduledId);
		return result;
	}

	public static boolean isValidGoals(String goals) {

		String regx = "^[A-Za-z0-9 ]{1,20}$";
		Pattern pattern = Pattern.compile(regx, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(goals);
		return matcher.find();

	}
	
	public static boolean isValidProgramName(String progName) {

		String regx = "^[A-Za-z0-9 ]{1,5}$";
		Pattern pattern = Pattern.compile(regx, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(progName);
		return matcher.find();

	}
	public static boolean isValidProgramId(String progId) {

		String regx = "^[A-Za-z0-9 ]{1,5}$";
		Pattern pattern = Pattern.compile(regx, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(progId);
		return matcher.find();

	}

	public static boolean isValidDescription(String progDescription) {

		String regx = "^[A-Za-z0-9 ]{2,20}$";
		Pattern pattern = Pattern.compile(regx, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(progDescription);
		return matcher.find();

	}
	
	public static boolean isValidCertName(String progDescription) {

		String regx = "^[A-Za-z0-9 ]{2,10}$";
		Pattern pattern = Pattern.compile(regx, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(progDescription);
		return matcher.find();

	}
}
