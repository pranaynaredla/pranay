package com.cg.auditorstimesheet.service;

import java.util.ArrayList;

import com.cg.auditorstimesheet.client.AuditorsTimeSheet;

public interface ITimeSheetService {

	public AuditorsTimeSheet addTimeSheetDetails(AuditorsTimeSheet timeSheet);

	public ArrayList<AuditorsTimeSheet> retrieveTimeSheetListDetails(
			AuditorsTimeSheet timeSheet);

}
