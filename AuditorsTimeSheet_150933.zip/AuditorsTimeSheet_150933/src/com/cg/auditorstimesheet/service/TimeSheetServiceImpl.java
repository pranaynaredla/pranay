package com.cg.auditorstimesheet.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.auditorstimesheet.client.AuditorsTimeSheet;
import com.cg.auditorstimesheet.dao.ITimeSheetDAO;

@Service
public class TimeSheetServiceImpl implements ITimeSheetService {

	@Autowired
	ITimeSheetDAO dao;

	@Override
	public AuditorsTimeSheet addTimeSheetDetails(AuditorsTimeSheet timeSheet) {
		return dao.addTimeSheetDetails(timeSheet);
	}

	@Override
	public ArrayList<AuditorsTimeSheet> retrieveTimeSheetListDetails(
			AuditorsTimeSheet timeSheet) {
		// TODO Auto-generated method stub
		return dao.retrieveTimeSheetListDetails(timeSheet);
	}

}
