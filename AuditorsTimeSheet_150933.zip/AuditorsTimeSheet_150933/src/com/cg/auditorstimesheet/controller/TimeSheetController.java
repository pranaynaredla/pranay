package com.cg.auditorstimesheet.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.auditorstimesheet.client.AuditorsTimeSheet;
import com.cg.auditorstimesheet.service.ITimeSheetService;

@Controller
public class TimeSheetController {

	@Autowired
	ITimeSheetService service;

	/**
	 * To display Home Page
	 */
	@RequestMapping("/index")
	public ModelAndView getHomePage() {
		ModelAndView view = new ModelAndView();
		view.setViewName("HomePage");
		return view;
	}

	/**
	 * To view TimeSheetEntry Page
	 */
	@RequestMapping("/entertimesheet")
	public ModelAndView timeSheetEntryPage() {
		ModelAndView view = new ModelAndView("TimeEntrySheet", "auditorts",
				new AuditorsTimeSheet());
		ArrayList<String> list = new ArrayList<>();
		list.add("DATA_ENTRY");
		list.add("ACCOUNTS_TALLY");
		list.add("LEDGER_POSTINGS");
		list.add("BALANCE_SHEET");
		list.add("RETURNS_FILING");
		view.addObject("activitylist", list);
		return view;
	}

	/**
	 * To Persist the data in DataBase
	 */
	@RequestMapping("/store")
	public ModelAndView addTimeSheet(
			@ModelAttribute("auditorts") @Valid AuditorsTimeSheet timeSheet,
			BindingResult bindingResult) {
		ModelAndView view = new ModelAndView();
		if (bindingResult.hasErrors()) {
			ArrayList<String> list = new ArrayList<>();
			list.add("DATA_ENTRY");
			list.add("ACCOUNTS_TALLY");
			list.add("LEDGER_POSTINGS");
			list.add("BALANCE_SHEET");
			list.add("RETURNS_FILING");
			view.addObject("activitylist", list);
			view.setViewName("TimeEntrySheet");
		} else {
			AuditorsTimeSheet sheet = service.addTimeSheetDetails(timeSheet);
			view.addObject("id", sheet.getTimesheetId());
			view.setViewName("Success");
		}
		return view;
	}

	/**
	 * To display the TimeSheetList Page
	 */
	@RequestMapping("/listtimesheet")
	public ModelAndView timeSheetListpage() {
		ModelAndView view = new ModelAndView("ListTimeSheet", "auditorts",
				new AuditorsTimeSheet());
		return view;
	}

	/**
	 * To retrieve Data from DataBase
	 */
	@RequestMapping("/retrieve")
	public ModelAndView retrieveTimeSheetList(
			@ModelAttribute("auditorts") AuditorsTimeSheet timeSheet) {
		ModelAndView view = new ModelAndView("ListTimeSheet");
		ArrayList<AuditorsTimeSheet> list = service
				.retrieveTimeSheetListDetails(timeSheet);
		if (list.isEmpty()) {
			view.addObject("message", "No time sheets recorded!");
		} else {
			view.addObject("timeSheetList", list);
			ArrayList<String> list2 = new ArrayList<>();
			list2.add("alter");
			view.addObject("list2", list2);
		}
		return view;
	}

}
