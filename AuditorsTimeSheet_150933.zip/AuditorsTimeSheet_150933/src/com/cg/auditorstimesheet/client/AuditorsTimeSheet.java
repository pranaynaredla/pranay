package com.cg.auditorstimesheet.client;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "TimeSheet")
@NamedQueries({ @NamedQuery(name = "retrieve", query = "SELECT a FROM AuditorsTimeSheet a WHERE a.empId=:id") })
public class AuditorsTimeSheet implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "timesheet_id")
	private Integer timesheetId;
	@Column(name = "emp_id")
	@Pattern(regexp = "[A-Z]{3}[0-9]{5}", message = "It should be in the format of ABC00001")
	@NotEmpty(message = "Please fill")
	private String empId;
	@Transient
	private String curDate;
	@Column(name = "hour1")
	@NotEmpty(message = "Please fill")
	private String hour1;
	@Column(name = "hour2")
	@NotEmpty(message = "Please fill")
	private String hour2;
	@Column(name = "hour3")
	@NotEmpty(message = "Please fill")
	private String hour3;
	@Column(name = "hour4")
	@NotEmpty(message = "Please fill")
	private String hour4;
	@Column(name = "hour5")
	@NotEmpty(message = "Please fill")
	private String hour5;
	@Column(name = "hour6")
	@NotEmpty(message = "Please fill")
	private String hour6;
	@Column(name = "hour7")
	@NotEmpty(message = "Please fill")
	private String hour7;
	@Column(name = "hour8")
	@NotEmpty(message = "Please fill")
	private String hour8;
	@Column(name = "timesheet_date")
	private Date timesheetDate;

	public Integer getTimesheetId() {
		return timesheetId;
	}

	public void setTimesheetId(Integer timesheetId) {
		this.timesheetId = timesheetId;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getHour1() {
		return hour1;
	}

	public void setHour1(String hour1) {
		this.hour1 = hour1;
	}

	public String getHour2() {
		return hour2;
	}

	public void setHour2(String hour2) {
		this.hour2 = hour2;
	}

	public String getHour3() {
		return hour3;
	}

	public void setHour3(String hour3) {
		this.hour3 = hour3;
	}

	public String getHour4() {
		return hour4;
	}

	public void setHour4(String hour4) {
		this.hour4 = hour4;
	}

	public String getHour5() {
		return hour5;
	}

	public void setHour5(String hour5) {
		this.hour5 = hour5;
	}

	public String getHour6() {
		return hour6;
	}

	public void setHour6(String hour6) {
		this.hour6 = hour6;
	}

	public String getHour7() {
		return hour7;
	}

	public void setHour7(String hour7) {
		this.hour7 = hour7;
	}

	public String getHour8() {
		return hour8;
	}

	public void setHour8(String hour8) {
		this.hour8 = hour8;
	}

	public String getCurDate() {
		return curDate;
	}

	public void setCurDate(String curDate) {
		this.curDate = curDate;
	}

	public Date getTimesheetDate() {
		return timesheetDate;
	}

	public void setTimesheetDate(Date timesheetDate) {
		this.timesheetDate = timesheetDate;
	}

	public AuditorsTimeSheet() {
	}
}
