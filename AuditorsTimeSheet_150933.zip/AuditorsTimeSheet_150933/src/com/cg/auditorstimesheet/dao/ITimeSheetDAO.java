package com.cg.auditorstimesheet.dao;

import java.util.ArrayList;

import com.cg.auditorstimesheet.client.AuditorsTimeSheet;

public interface ITimeSheetDAO {
	public AuditorsTimeSheet addTimeSheetDetails(AuditorsTimeSheet timeSheet);

	public ArrayList<AuditorsTimeSheet> retrieveTimeSheetListDetails(
			AuditorsTimeSheet timeSheet);
}
