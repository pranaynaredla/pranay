package com.cg.auditorstimesheet.dao;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.auditorstimesheet.client.AuditorsTimeSheet;

@Repository
@Transactional
public class TimeSheetDAOImpl implements ITimeSheetDAO {

	@PersistenceContext
	EntityManager entityManager;
	
	/**************************************************************************************
	*Method Name               : addTimeSheetDetails()
	*Author Name               : Pranay Naredla_150933(Capgemini)
	*Desc                      : Implementation to add time Sheet details
	*Version                   : 1.0
	*Created Date              : 10-JUL-2018
	*Input Parameters          : AuditorsTimeSheet object
	*Return Type               : <Object>
	**************************************************************************************/
	@Override
	public AuditorsTimeSheet addTimeSheetDetails(AuditorsTimeSheet timeSheet) {
		try {
			String currentDate = timeSheet.getCurDate();
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date date = format.parse(currentDate);
			Date timeSheetDate = new Date(date.getTime());
			timeSheet.setTimesheetDate(timeSheetDate);
			entityManager.persist(timeSheet);
			entityManager.flush();
		} catch (Exception e) {

		}
		return timeSheet;
	}
	
	/**************************************************************************************
	*Method Name               : retrieveTimeSheetListDetails()
	*Author Name               : Pranay Naredla_150933(Capgemini)
	*Desc                      : Implementation to retrieve Time Sheet Details
	*Version                   : 1.0
	*Created Date              : 10-JUL-2018
	*Input Parameters          : AuditorsTimeSheet object
	*Return Type               : ArrayList<Object>
	**************************************************************************************/
	@Override
	public ArrayList<AuditorsTimeSheet> retrieveTimeSheetListDetails(
			AuditorsTimeSheet timeSheet) {
		Query query = entityManager.createNamedQuery("retrieve");
		@SuppressWarnings("unchecked")
		ArrayList<AuditorsTimeSheet> list = (ArrayList<AuditorsTimeSheet>) query
				.setParameter("id", timeSheet.getEmpId()).getResultList();
		return list;
	}

}
