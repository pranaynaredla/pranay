package com.capgemini.universityadmission.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validation {

	public static boolean validateFullName(String txt) {

	    String regx = "^[A-Za-z][a-z ]*$";
	    Pattern pattern = Pattern.compile(regx,Pattern.CASE_INSENSITIVE);
	    Matcher matcher = pattern.matcher(txt);
	    return matcher.find();

	}
}
