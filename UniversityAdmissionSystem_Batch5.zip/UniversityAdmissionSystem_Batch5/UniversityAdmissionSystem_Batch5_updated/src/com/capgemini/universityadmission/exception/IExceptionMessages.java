package com.capgemini.universityadmission.exception;

public interface IExceptionMessages {

	String MESSAGE1 = "Property File not found...!!";
	String MESSAGE2 = "Driver Class not found..!!";
	String MESSAGE3 = "Problem in reading property..!!";
	String MESSAGE4 = "Problem in obtaining connection..!!";
	String MESSAGE5 = "Data not available...!!";
	String MESSAGE6 = "Participants are not added..!";

}
