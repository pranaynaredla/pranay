package com.capgemini.universityadmission.exception;

public interface IExceptionMessages {

	String MESSAGE1 = "Property File not found...!!";
	String MESSAGE2 = "Driver Class not found..!!";
	String MESSAGE3 = "Problem in reading property..!!";
	String MESSAGE4 = "Problem in obtaining connection..!!";
	String MESSAGE5 = "Data not available...!!";
	String MESSAGE6 = "Participants are not added..!";
	String MESSAGE7 = "Scheduled Programs are not available";
	String MESSAGE8 = "Programs offered are not available";
	String MESSAGE9 = "No data available to filter and update the status";
	String MESSAGE10 = "No participants available";

}
