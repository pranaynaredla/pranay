package com.capgemini.universityadmission.junit;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.jupiter.api.Test;

import com.capgemini.universityadmission.bean.Application;
import com.capgemini.universityadmission.exception.UASException;
import com.capgemini.universityadmission.service.IUniversityService;
import com.capgemini.universityadmission.service.UniversityServiceImpl;

class UniversityServiceImplTest {

	@Test
	void testApplicantDetails() throws UASException {
		IUniversityService service=new UniversityServiceImpl();
		Application application=new Application();
		application.setFullName("Pranay Naredla");
		String dateOfBirth="25/02/1997";
		LocalDate ld;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		ld = LocalDate.parse(dateOfBirth, formatter);
		application.setDateOfBirth(ld);
		application.setHighestQualification("B Tech");
		application.setMarksObtained(72);
		application.setGoals("S/W H/W");
		application.setEmailId("pn@g.com");
		application.setScheduledProgramId("101");
		application.setStatus("accepted");
		int i= service.applicantDetails(application);
		assertEquals(1005,i);
		}

}
