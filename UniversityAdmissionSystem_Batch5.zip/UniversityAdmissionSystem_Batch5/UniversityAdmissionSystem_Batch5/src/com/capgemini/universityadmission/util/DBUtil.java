package com.capgemini.universityadmission.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.capgemini.universityadmission.exception.UASException;

public class DBUtil {
	private static Connection conn=null;
	public static Connection getConnection() throws UASException{
		if(conn==null){
			try {
				FileInputStream fin = new FileInputStream("resources/JDBC.properties");
				Properties props = new Properties();
				props.load(fin);			
				String driver = props.getProperty("db.driver");
				String url = props.getProperty("db.url");
				String user = props.getProperty("db.user");
				String pass = props.getProperty("db.pass");
				Class.forName(driver);
				conn = DriverManager.getConnection(url, user, pass);
				conn.commit();
			} catch (FileNotFoundException e) {
				throw new UASException("Property file not found.."+e.getMessage());
			} catch (ClassNotFoundException e) {
				throw new UASException("Driver class not found.."+e.getMessage());
			} catch (IOException e) {
				throw new UASException("Problem in reading property.."+e.getMessage());
			} catch (SQLException e) {
				e.printStackTrace();
				throw new UASException("Problem in obtaining connection.."+e.getMessage());
			}	
		}
		return conn;
	}
}
