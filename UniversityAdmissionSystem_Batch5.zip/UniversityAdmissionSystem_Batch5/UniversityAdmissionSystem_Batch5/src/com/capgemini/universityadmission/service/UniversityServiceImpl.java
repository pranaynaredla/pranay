package com.capgemini.universityadmission.service;

import java.util.ArrayList;

import com.capgemini.universityadmission.bean.Application;
import com.capgemini.universityadmission.bean.ProgramsOffered;
import com.capgemini.universityadmission.bean.ProgramsScheduled;
import com.capgemini.universityadmission.dao.IUniversityDao;
import com.capgemini.universityadmission.dao.UniversityDaoImpl;
import com.capgemini.universityadmission.exception.UASException;

public class UniversityServiceImpl implements IUniversityService {
	IUniversityDao universityDao=new UniversityDaoImpl();
	@Override
	public ArrayList<ProgramsOffered> viewAllPrograms() throws UASException {
		return universityDao.viewAllPrograms();
	}

	@Override
	public ArrayList<ProgramsScheduled> viewScheduledPrograms() throws UASException {
		return universityDao.viewScheduledPrograms();
	}

	@Override
	public Integer applicantDetails(Application application) throws UASException {
		return universityDao.applicantDetails(application);
	}

	@Override
	public boolean adminLogin(String userName, String password, String role) throws UASException {
		return universityDao.adminLogin(userName, password, role);
	}

	@Override
	public Application applicantStatus(Integer id) throws UASException {
		return universityDao.applicantStatus(id);
	}

	@Override
	public Integer updateStatus(Integer applicantId) throws UASException {
		return universityDao.updateStatus(applicantId);
	}

	@Override
	public Integer addParticipants(Application application) throws UASException {
		return universityDao.addParticipants(application);
	}

	@Override
	public ArrayList<Application> memberOfAdmin(String progName) throws UASException {
		return universityDao.memberOfAdmin(progName);
	}

	@Override
	public Integer deletePrograms() throws UASException {
		return universityDao.deletePrograms();
	}

	@Override
	public Integer insertProgram(ProgramsScheduled programsScheduled) throws UASException {
		return universityDao.insertProgram(programsScheduled);
	}

}
