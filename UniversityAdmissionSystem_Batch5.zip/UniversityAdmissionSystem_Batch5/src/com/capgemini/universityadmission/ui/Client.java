package com.capgemini.universityadmission.ui;

import java.sql.Connection;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.universityadmission.bean.Application;
import com.capgemini.universityadmission.bean.ProgramsOffered;
import com.capgemini.universityadmission.bean.ProgramsScheduled;
import com.capgemini.universityadmission.dao.IUniversityDao;
import com.capgemini.universityadmission.dao.UniversityDaoImpl;
import com.capgemini.universityadmission.exception.UASException;

public class Client {
	public static void main(String[] args) throws UASException {
		System.out.println("*****************************");
		System.out.println("*UNIVERSITY ADMISSION SYSTEM*");
		System.out.println("*****************************");
		int choice = -1;
		do {
			System.out
					.println("1.View Programs\n2.Register to a Program\n3.Applicant Status\n4.Login as Admin\n5.Exit");
			Scanner scanner = new Scanner(System.in);
			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("**********************");
				System.out.println("***Programs Offered***");
				System.out.println("**********************");
				ArrayList<ProgramsOffered> list = new ArrayList<>();
				IUniversityDao dao = new UniversityDaoImpl();
				list = dao.viewAllPrograms();
				for (ProgramsOffered po : list) {
					System.out.println(po.getProgramName() + " "
							+ po.getProgramDescription() + " "
							+ po.getApplicantEligibility() + " "
							+ po.getProgramDuration() + " "
							+ po.getDegreeCertOffered());
				}
				System.out.println("************************");
				System.out.println("***Scheduled Programs***");
				System.out.println("************************");
				ArrayList<ProgramsScheduled> list1 = new ArrayList<>();
				list1 = dao.viewScheduledPrograms();
				for (ProgramsScheduled ps : list1) {
					System.out.println(ps.getScheduledProgramId() + " "
							+ ps.getProgramName() + " " + ps.getLocation()
							+ " " + ps.getStartDate() + " " + ps.getEndDate()
							+ " " + ps.getSessionsPerWeek());
				}
				break;
			case 2:
				IUniversityDao dao1 = new UniversityDaoImpl();
				Application application = new Application();
				System.out.println("Enter Full Name");
				String fullName = scanner.next();
				application.setFullName(fullName);
				// scanner.nextLine();
				System.out.println("Enter Date Of Birth");
				String dateOfBirth = scanner.next();
				LocalDate ld;
				DateTimeFormatter formatter = DateTimeFormatter
						.ofPattern("dd/MM/yyyy");
				ld = LocalDate.parse(dateOfBirth, formatter);
				application.setDateOfBirth(ld);

				System.out.println("Enter highest Qualification");
				String highestQualification = scanner.next();
				application.setHighestQualification(highestQualification);
				System.out.println("Enter Marks Obtained");
				Integer marksObtained = scanner.nextInt();
				application.setMarksObtained(marksObtained);
				System.out.println("Enter Gaols");
				String goals = scanner.next();
				application.setGoals(goals);
				// scanner.nextLine();
				System.out.println("Enter Email ID");
				String emailId = scanner.next();
				application.setEmailId(emailId);
				// scanner.nextLine();
				System.out.println("Enter Program Scheduled ID");
				String scheduledId = scanner.next();
				application.setScheduledProgramId(scheduledId);
				
				int id=dao1.applicantDetails(application);
				
				if (id != 0){
					System.out.println("Registered Successfully");
				System.out.println("Your applicantId is "+id);
				}
				else
					System.out.println("Not Registered Successfully");
				break;
			case 3:
				IUniversityDao dao3 = new UniversityDaoImpl();
				System.out.println("Please enter your ApplicantID");
				Scanner scanner1 = new Scanner(System.in);
				Integer applicantId = scanner1.nextInt();
				String status=dao3.applicantStatus(applicantId);
				System.out.println("Your application status is "+status.toUpperCase());
				break;
			case 4:
				Application application2=new Application();
				IUniversityDao dao2 = new UniversityDaoImpl();
				System.out.println("Enter UserName");
				Scanner scanner2 = new Scanner(System.in);
				String userName = scanner2.next();
				System.out.println("Enter Password");
				String password = scanner2.next();
				System.out.println("Enter your Role");
				String role = scanner2.next();
				boolean auth = dao2.adminLogin(userName, password, role);
				if (auth) {
					if (role.equals("mac")) {
						ArrayList<Application> list3 = new ArrayList<>();
						list3 = dao2.memberOfAdmin();
						for (Application a : list3) {
							System.out.println(a.getApplicantId() + " "
									+ a.getFullName() + " "
									+ a.getMarksObtained());
						}
						for (Application b: list3){
							if(dao2.updateStatus(b.getApplicantId())==1){
								System.out.println(b.getApplicantId()+"is updated");
							}
							else
								System.out.println(b.getApplicantId()+" is not updated");
						}
						dao2.addParticipants(application2);
					} else {
							
					}
				}
				break;
			case 5:
				System.out.println("Thank You...!!");
				System.exit(0);
				break;
			}
		} while (choice != 0);
	}
}
