package com.capgemini.universityadmission.dao;

import java.util.ArrayList;

import com.capgemini.universityadmission.bean.Application;
import com.capgemini.universityadmission.bean.ProgramsOffered;
import com.capgemini.universityadmission.bean.ProgramsScheduled;
import com.capgemini.universityadmission.exception.UASException;

public interface IUniversityDao {
	public ArrayList<ProgramsOffered> viewAllPrograms() throws UASException;

	public ArrayList<ProgramsScheduled> viewScheduledPrograms()
			throws UASException;

	public Integer applicantDetails(Application application)
			throws UASException;

	public boolean adminLogin(String userName, String password, String role)
			throws UASException;

	public ArrayList<Application> memberOfAdmin() throws UASException;

	public String applicantStatus(Integer id) throws UASException;

	public Integer updateStatus(Integer applicantId)
			throws UASException;
	
	public Integer addParticipants(Application application) throws UASException;
	
}
