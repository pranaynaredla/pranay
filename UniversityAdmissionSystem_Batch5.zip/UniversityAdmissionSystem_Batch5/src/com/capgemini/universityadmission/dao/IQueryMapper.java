package com.capgemini.universityadmission.dao;

public interface IQueryMapper {

	String QUERY1 = "SELECT program_name,description,applicant_eligibility,duration,degree_certificate_offered FROM programs_offered";
	String QUERY2 = "SELECT scheduled_program_id,program_name,location,start_date,end_date,sessions_per_week FROM programs_scheduled";
	String QUERY3 = "INSERT INTO application VALUES(applicant_id_seq.NEXTVAL,?,?,?,?,?,?,?,?,SYSDATE)";
	String QUERY4 = "SELECT login_id,password,role FROM user_details";
	String QUERY5 = "SELECT a.applicant_id,a.full_name,a.marks_obtained FROM application a JOIN programs_scheduled p ON a.scheduled_program_id=p.scheduled_program_id WHERE p.program_name=?";
	String QUERY6 = "SELECT status FROM application WHERE applicant_id=?";
	String QUERY7 = "UPDATE application SET status=? ,date_of_interview=date_of_interview+5 WHERE applicant_id=? and marks_obtained>?";
	String QUERY8 = "INSERT INTO participant VALUES(roll_no_seq.NEXTVAL,?,?,?)";
	String QUERY9 = "SELECT email_id,applicant_id,scheduled_program_id FROM application WHERE status=?";
	String QUERY10 = "DELETE * FROM programs_scheduled WHERE SYSDATE>end_date";
	String QUERY11 = "INSERT INTO programs_scheduled VALUES(?,?,?,?,?,?,?)";

}
