package com.capgemini.universityadmission.exception;

public class UASException extends Exception {

	public UASException() {
	}

	public UASException(String arg0) {
		super(arg0);
	}

}
