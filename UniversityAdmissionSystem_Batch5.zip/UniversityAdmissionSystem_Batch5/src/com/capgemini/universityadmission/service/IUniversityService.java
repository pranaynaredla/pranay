package com.capgemini.universityadmission.service;

public interface IUniversityService{

}
