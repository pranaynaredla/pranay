package com.capgemini.universityadmission.service;

public class UniversityServiceImpl implements IUniversityService{

}
