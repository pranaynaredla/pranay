package com.cg.dao;

import com.cg.client.GearQuiz;

public interface IQuestionDAO {

	public GearQuiz addQues(GearQuiz bean);
}
