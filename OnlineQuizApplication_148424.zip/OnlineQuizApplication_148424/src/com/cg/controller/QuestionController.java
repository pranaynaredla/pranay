package com.cg.controller;


import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.client.GearQuiz;
import com.cg.service.IQuestionService;

@Controller
public class QuestionController {
	
	@Autowired
	IQuestionService service;
	
	@RequestMapping("index")
	public String homepage()
	{
		String view = null;
		view ="HomePage";
		return view;
	}
	
	
	@RequestMapping("addquestion")
	public String addQuestion(Model model)
	{
		GearQuiz bean = new GearQuiz();
		long millis =System.currentTimeMillis();
		java.util.Date date = new java.util.Date(millis);
		model.addAttribute("date", date);
		model.addAttribute("bean", bean);
		model.addAttribute("seltopic",new String[]{"MATHS","HISTORY","SCIENCE"});
		
		return "Add_Question";
	}
	
	@RequestMapping(value="insert", method=RequestMethod.POST)
	public String insertQues(Model model, @ModelAttribute("bean")@Valid GearQuiz bean, BindingResult result)
	{
	    String string = null;
	    String view=null;
	    ArrayList<String> arraylist = new ArrayList();
	    arraylist.add(bean.getOp1());
	    arraylist.add(bean.getOp2());
	    arraylist.add(bean.getOp3());
	    arraylist.add(bean.getOp4());
	    boolean a = true;
	    //a= arraylist.contains(bean.getAns());
	    if(bean.getReviewCnt()==0){
			string ="Questions must be reviewed";
			bean.setRemark(string);
		}
	    
	    if(result.hasErrors()){
	    	view = "Add_Question";
	    }
	    
	    
	    else if(a==false){
	    	model.addAttribute("msg", "Select the option which is present in the given options");
	    	view = "Add_Question";
	    }
	    	else{
	    	GearQuiz obj = service.addQues(bean);
			model.addAttribute("bean", obj);
			model.addAttribute("id", bean.getqNo());
			view = "success";
	    	
	    }
		System.out.println(view);
		return view;
	}

}
