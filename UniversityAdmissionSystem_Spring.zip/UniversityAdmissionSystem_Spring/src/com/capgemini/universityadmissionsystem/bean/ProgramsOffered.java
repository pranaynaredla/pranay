package com.capgemini.universityadmissionsystem.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="")
@NamedQueries({@NamedQuery(name="",query=""),@NamedQuery(name="",query="")})
public class ProgramsOffered implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private Integer programId;
	@Column(name="")
	private String programName;
	@Column(name="")
	private String programDescription;
	@Column(name="")
	private String applicantEligibility;
	@Column(name="")
	private Integer programDuration;
	@Column(name="")
	private String degreeCertOffered;

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getProgramDescription() {
		return programDescription;
	}

	public void setProgramDescription(String programDescription) {
		this.programDescription = programDescription;
	}

	public String getApplicantEligibility() {
		return applicantEligibility;
	}

	public void setApplicantEligibility(String applicantEligibility) {
		this.applicantEligibility = applicantEligibility;
	}

	public Integer getProgramDuration() {
		return programDuration;
	}

	public void setProgramDuration(Integer programDuration) {
		this.programDuration = programDuration;
	}

	public String getDegreeCertOffered() {
		return degreeCertOffered;
	}

	public void setDegreeCertOffered(String degreeCertOffered) {
		this.degreeCertOffered = degreeCertOffered;
	}

}
