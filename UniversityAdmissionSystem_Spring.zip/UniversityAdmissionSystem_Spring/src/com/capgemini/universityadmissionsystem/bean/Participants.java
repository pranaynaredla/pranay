package com.capgemini.universityadmissionsystem.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="")
@NamedQueries({@NamedQuery(name="",query=""),@NamedQuery(name="",query="")})
public class Participants implements Serializable {

	private static final long serialVersionUID = 1L;

	private String rollNo;
	@Column(name="")
	private String emailId;
	@Column(name="")
	private Integer applicantId;
	@Column(name="")
	private String scheduledProgramId;

	public String getRollNo() {
		return rollNo;
	}

	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Integer getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(Integer applicantId) {
		this.applicantId = applicantId;
	}

	public String getScheduledProgramId() {
		return scheduledProgramId;
	}

	public void setScheduledProgramId(String scheduledProgramId) {
		this.scheduledProgramId = scheduledProgramId;
	}
}
