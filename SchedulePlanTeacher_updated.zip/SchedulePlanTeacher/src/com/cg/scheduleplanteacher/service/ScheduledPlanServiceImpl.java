package com.cg.scheduleplanteacher.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.scheduleplanteacher.bean.Teachers;
import com.cg.scheduleplanteacher.dao.ISchedulePlanDao;

@Service("service")
public class ScheduledPlanServiceImpl implements ISchedulePlanService{
	
	@Autowired
	ISchedulePlanDao planDao;

	@Override
	public Teachers addPlan(Teachers teachers) {
		// TODO Auto-generated method stub
		return planDao.addPlan(teachers);
	}

	@Override
	public ArrayList<Teachers> viewAllPlan() {
		// TODO Auto-generated method stub
		return planDao.viewAllPlan();
	}

	@Override
	public ArrayList<Teachers> viewByPlanId(Integer id) {
		// TODO Auto-generated method stub
		return planDao.viewByPlanId(id);
	}

}
