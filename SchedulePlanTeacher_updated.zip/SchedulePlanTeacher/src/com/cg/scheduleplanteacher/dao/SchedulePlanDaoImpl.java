package com.cg.scheduleplanteacher.dao;

import java.util.ArrayList;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.cg.scheduleplanteacher.bean.Teachers;

@Repository("dao")
@Transactional
public class SchedulePlanDaoImpl implements ISchedulePlanDao{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Teachers addPlan(Teachers teachers) {
		entityManager.persist(teachers);
		entityManager.flush();
		
		return  teachers;
	}

	@Override
	public ArrayList<Teachers> viewAllPlan() {
		Query query=entityManager.createNamedQuery("viewall");
		@SuppressWarnings("unchecked")
		ArrayList<Teachers> list=(ArrayList<Teachers>) query.getResultList();
		return list;
	}

	@Override
	public ArrayList<Teachers> viewByPlanId(Integer id) {
		Query query=entityManager.createNamedQuery("viewallbyid");
		@SuppressWarnings("unchecked")
		ArrayList<Teachers> list=(ArrayList<Teachers>) query.setParameter("id", id).getResultList();
		return list;	
		}

}
