package com.capgemini.universityadmissionsystem.service;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.universityadmissionsystem.bean.Application;
import com.capgemini.universityadmissionsystem.bean.Participants;
import com.capgemini.universityadmissionsystem.bean.ProgramsOffered;
import com.capgemini.universityadmissionsystem.bean.ProgramsScheduled;
import com.capgemini.universityadmissionsystem.bean.Users;
import com.capgemini.universityadmissionsystem.dao.IUniversityDao;

@Service
public class UniversityServiceImpl implements IUniversityService {

	@Autowired
	IUniversityDao dao;

	@Override
	public List<Users> authenticateUser(Users users) {
		return dao.authenticateUser(users);
	}

	@Override
	public List<ProgramsOffered> displayProgramsOffered() {

		return dao.displayProgramsOffered();
	}

	@Override
	public List<ProgramsScheduled> displayProgramsScheduled() {
		return dao.displayProgramsScheduled();
	}

	@Override
	public Integer addApplicantDetails(Application application) {
		return dao.addApplicantDetails(application);
	}

	@Override
	public List<Application> retrieveFilteredApplicants(
			ProgramsScheduled scheduled) {
		return dao.retrieveFilteredApplicants(scheduled);
	}

	@Override
	public List<Application> applicantStatus(Integer id) {

		return dao.applicantStatus(id);
	}

	@Override
	public List<Participants> displayParticipants() {

		return dao.displayParticipants();
	}

	@Override
	public List<Application> displayApplicants() {

		return dao.displayApplicants();
	}

	@Override
	public List<Application> getAcceptedApplicants() {

		return dao.getAcceptedApplicants();
	}

	@Override
	public void confirmOrRejectApplicants(Integer applicantId,
			String applicantStatus) {
		dao.confirmOrRejectApplicants(applicantId, applicantStatus);

	}

	@Override
	public void addProgramsOffered(ProgramsOffered programsOffered) {
		dao.addProgramsOffered(programsOffered);

	}

	@Override
	public void addProgramsScheduled(ProgramsScheduled programsScheduled) {
		dao.addProgramsScheduled(programsScheduled);

	}

	@Override
	public void deleteProgramOffered(String programName) {
		dao.deleteProgramOffered(programName);
	}

	@Override
	public void deleteProgramsScheduled(String scheduledId) {
		dao.deleteProgramsScheduled(scheduledId);
	}

	@Override
	public void updateApplicantStatus(String status,Integer applicantId,Date date) {
		dao.updateApplicantStatus(status,applicantId,date);
	}

	@Override
	public List<Application> addParticipantDetails() {
		return dao.addParticipantDetails();
	}

}
