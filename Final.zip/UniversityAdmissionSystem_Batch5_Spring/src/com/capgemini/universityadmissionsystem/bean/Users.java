package com.capgemini.universityadmissionsystem.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "Users")
@NamedQuery(name="validateLogin",query="SELECT user FROM Users user WHERE user.loginId=:loginId AND user.password=:password")
public class Users implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "login_id")
	@NotEmpty(message = "UserName should not be Empty")
	private String loginId;

	@Column(name = "password")
	@NotEmpty(message = "Password should not be Empty")
	private String password;

	@Column(name = "role")
	//@NotEmpty(message = "Select the Role")
	private String role;

	public Users() {

	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

}
