package com.capgemini.universityadmissionsystem.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Participant")
@NamedQuery(name="getParticipants",query="SELECT participant FROM Participants participant")
@SequenceGenerator(name="roll_num_seq",sequenceName="roll_no_seq",allocationSize=1)
public class Participants implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(generator="roll_num_seq")
	@Column(name="roll_no")
	private Integer rollNo;
	
	@Column(name="email_id")
	@NotEmpty(message="Please enter email... This is a required field")
	private String emailId;
	
	@Column(name="applicant_id")
	@NotNull(message="Please enter applicant ID...... This is a required field")
	private Integer applicantId;
	
	@Column(name="scheduled_program_id")
	@NotEmpty(message="Please enter scheduled program ID.... This is a required field")
	private String scheduledProgramId;

	public Participants() {
	}
	public Integer getRollNo() {
		return rollNo;
	}

	public void setRollNo(Integer rollNo) {
		this.rollNo = rollNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Integer getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(Integer applicantId) {
		this.applicantId = applicantId;
	}

	public String getScheduledProgramId() {
		return scheduledProgramId;
	}

	public void setScheduledProgramId(String scheduledProgramId) {
		this.scheduledProgramId = scheduledProgramId;
	}

}
