package com.capgemini.universityadmissionsystem.bean;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "Application")
@NamedQueries({ @NamedQuery(name = "getApplicants", query = "SELECT applicant FROM Application applicant WHERE applicant.scheduledProgramId IS NOT NULL"),@NamedQuery(name = "getUpdateStatus", query =
		 "UPDATE Application applicant SET applicant.status=:status,applicant.dateOfInterview=:date WHERE applicant.applicantId=:id"),
		 @NamedQuery(name="getApplicantStatus", query="SELECT application FROM Application application WHERE application.applicantId=:id"),
		 @NamedQuery(name = "getConfirmRejectStatus", query =
				 "UPDATE Application applicant SET applicant.status=:status WHERE applicant.applicantId=:id"),
				 @NamedQuery(name="getAcceptedApplicantStatus", query="SELECT applicant FROM Application applicant WHERE applicant.status=:status AND applicant.dateOfInterview=:date")})
@SequenceGenerator(name="application_id_seq",sequenceName="applicant_id_seq",allocationSize=1)
public class Application implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator="application_id_seq") 
	@Column(name = "applicant_id")
	private Integer applicantId;
	@NotEmpty(message = "Required field")
	@Pattern(regexp = "^[A-Za-z][A-Za-z ]{2,19}$", message = "No digits allowed")
	@Column(name = "full_name")
	private String fullName;
	@Transient
	@NotEmpty(message = "Required field")
	@Pattern(regexp="^(3[01]|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/199[0-9]{1}$",message="InValid D-O-B")
	private String dob;
	@Column(name = "date_of_birth")
	private Date dateOfBirth;
	@Column(name = "highest_qualification")
	@NotEmpty(message = "Required field")
	private String highestQualification;
	@Column(name = "marks_obtained")
	@NotNull(message = "Required field")
	@Range(min=0,max=100)
	private Integer marksObtained;
	@Column(name = "goals")
	@NotEmpty(message = "Required field")
	private String goals;
	@Column(name = "email_id")
	@Pattern(regexp = "[A-Za-z0-9]+@[A-Za-z0-9.-]+[.][A-Za-z]{2,4}", message = "Invalid email address")
	private String emailId;
	@Column(name = "scheduled_program_id")
	//@NotEmpty(message = "Required field")
	private String scheduledProgramId;
	@Column(name = "status")
	private String status;
	@Column(name = "date_of_interview")
	private Date dateOfInterview;

	public Application() {
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public Integer getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(Integer applicantId) {
		this.applicantId = applicantId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getHighestQualification() {
		return highestQualification;
	}

	public void setHighestQualification(String highestQualification) {
		this.highestQualification = highestQualification;
	}

	public Integer getMarksObtained() {
		return marksObtained;
	}

	public void setMarksObtained(Integer marksObtained) {
		this.marksObtained = marksObtained;
	}

	public String getGoals() {
		return goals;
	}

	public void setGoals(String goals) {
		this.goals = goals;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getScheduledProgramId() {
		return scheduledProgramId;
	}

	public void setScheduledProgramId(String scheduledProgramId) {
		this.scheduledProgramId = scheduledProgramId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getDateOfInterview() {
		return dateOfInterview;
	}

	public void setDateOfInterview(Date dateOfInterview) {
		this.dateOfInterview = dateOfInterview;
	}

	@Override
	public String toString() {
		return "applicantId=" + applicantId + ", fullName="
				+ fullName + ", dob=" + dob + ", dateOfBirth=" + dateOfBirth
				+ ", highestQualification=" + highestQualification
				+ ", marksObtained=" + marksObtained + ", goals=" + goals
				+ ", emailId=" + emailId + ", scheduledProgramId="
				+ scheduledProgramId + ", status=" + status
				+ ", dateOfInterview=" + dateOfInterview;
	}

}
