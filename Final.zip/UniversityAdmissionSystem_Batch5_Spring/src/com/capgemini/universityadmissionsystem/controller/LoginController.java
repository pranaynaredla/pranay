package com.capgemini.universityadmissionsystem.controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.universityadmissionsystem.bean.Users;
import com.capgemini.universityadmissionsystem.service.IUniversityService;

@Controller
public class LoginController {

	@Autowired
	IUniversityService service;

	@RequestMapping("index")
	public String getHome() {
		return "Home";

	}

	@RequestMapping(value = "index", method = RequestMethod.POST)
	public String getBack() {
		return "Home";
	}

	@RequestMapping(value = "/login")
	public String getLogin(Model model) {
		Users users = new Users();
		model.addAttribute("userKey", users);

		return "login";
	}
	@RequestMapping("logout")
	public String getLogOut() {
		String view="LogOut";
		return view;
		
	}

	@RequestMapping(value = "/valid", method = RequestMethod.POST)
	public ModelAndView validateUser(@ModelAttribute("userKey") @Valid Users users, BindingResult result,HttpSession session) {
		ModelAndView view = new ModelAndView();
		if (result.hasErrors()) {
			view.addObject("userKey", users);
			view.setViewName("login");

		} else {
			List<Users> list = service.authenticateUser(users);
			session.setAttribute("userName", list.get(0).getLoginId());
			
			if (!list.isEmpty() && list.get(0).getRole().equalsIgnoreCase("mac")) {
				view.setViewName("Mac");
			} else if (!list.isEmpty() && list.get(0).getRole().equalsIgnoreCase("admin")) {
				view.setViewName("Admin");
			} else {
				view.addObject("userKey", users);
				view.setViewName("login");
			}
		}
		return view;

	}
}
