package com.capgemini.universityadmissionsystem.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.universityadmissionsystem.bean.Application;
import com.capgemini.universityadmissionsystem.bean.ProgramsOffered;
import com.capgemini.universityadmissionsystem.bean.ProgramsScheduled;
import com.capgemini.universityadmissionsystem.service.IUniversityService;

@Controller
public class ApplicantController {

	@Autowired
	IUniversityService service;

	@RequestMapping("/viewProgramsOffered")
	public ModelAndView getProgramsOffered() {
		ModelAndView view = new ModelAndView("Home");
		List<ProgramsOffered> list = service.displayProgramsOffered();
		view.addObject("programsOfferedList", list);
		return view;
	}
	
	@RequestMapping("/viewProgramsScheduled")
	public ModelAndView getProgramsScheduled() {
		ModelAndView view = new ModelAndView("Home");
		List<ProgramsScheduled> list = service.displayProgramsScheduled();
		view.addObject("programsScheduledList", list);
		return view;
	}
	
	@RequestMapping(value="/register",method=RequestMethod.POST)
	public ModelAndView getRegistrationPage(@RequestParam("scheduledId") String scheduledId) {
		ModelAndView view = new ModelAndView("register","applicationKey",new Application());
		List<String> list = getQualificationList();
		List<String> list1 = getGoalsList();
		view.addObject("qualificationList", list);
		view.addObject("goalsList", list1);
		view.addObject("scheduledId", scheduledId);
		return view;
	}
	
	@RequestMapping(value="/toRegister",method=RequestMethod.POST)
	public ModelAndView getBackRegistrationPage() {
		ModelAndView view = new ModelAndView("register","applicationKey",new Application());
		List<String> list = getQualificationList();
		List<String> list1 = getGoalsList();
		view.addObject("qualificationList", list);
		view.addObject("goalsList", list1);
		return view;
	}
	
	private List<String> getQualificationList() {

		List<String> list = new ArrayList<String>();
		list.add("B.Tech");
		list.add("M.Tech");
		list.add("MBA");
		list.add("MCA");
		return list;

	}
	
	private List<String> getGoalsList() {

		List<String> list = new ArrayList<String>();
		list.add("Developer");
		list.add("Tester");
		list.add("Analyst");
		list.add("Scientist");
		list.add("Designer");
		return list;

	}
	
	@RequestMapping(value="store",method=RequestMethod.POST)
	public ModelAndView addApplicant(@ModelAttribute("applicationKey") @Valid Application application,BindingResult bindingResult,@RequestParam("scheduledId") String scheduledId){
		Integer result=0;
		ModelAndView view=new ModelAndView();
		if(bindingResult.hasErrors()){
			List<String> list = getQualificationList();
			List<String> list1 = getGoalsList();
			view.addObject("goalsList", list1);
			view.addObject("qualificationList", list);
			view.addObject("scheduledId", scheduledId);
			view.setViewName("register");
		}
		else{
			result=service.addApplicantDetails(application);
			if(result!=null){
				view.addObject("applicantId",result );
				view.addObject("applicationKey",application);
			}
			else{
				view.addObject("errorMsg", "Please try again later...! Registration Unsuccessful");
			}
			view.setViewName("displayId");
		}
		return view;
		
	}
	
	@RequestMapping("viewApplicantStatus")
	public ModelAndView getApplicantStatusPage() {
		ModelAndView view=new ModelAndView("applicantStatus");
		return view;
	}
	
	@RequestMapping(value="checkStatus",method=RequestMethod.POST)
	public ModelAndView viewApplicantStatus(@RequestParam("applicantId") String id) {
		ModelAndView view=new ModelAndView("applicantStatus");
		List<Application> list=service.applicantStatus(Integer.parseInt(id));
		if(list.isEmpty()){
			view.addObject("errorMsg","Please enter valid applicant Id");
		}
		else if(list.get(0).getScheduledProgramId()==null){
			view.addObject("errorMsg","Sorry.. Please register for another scheduled program");
		}
			
		else if(list.get(0).getStatus().equals("accepted")){
		view.addObject("status",list.get(0).getStatus()+" and your date of interview is "+list.get(0).getDateOfInterview());
		}
		else{
			view.addObject("status", list.get(0).getStatus());
		}
		return view;
		
	}
	
	
}
