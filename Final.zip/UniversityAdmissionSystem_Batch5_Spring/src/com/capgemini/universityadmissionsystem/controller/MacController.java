package com.capgemini.universityadmissionsystem.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.universityadmissionsystem.bean.Application;
import com.capgemini.universityadmissionsystem.bean.Participants;
import com.capgemini.universityadmissionsystem.bean.ProgramsScheduled;
import com.capgemini.universityadmissionsystem.service.IUniversityService;

@Controller
public class MacController {

	@Autowired
	IUniversityService service;

	@RequestMapping(value = "/mac")
	public String getMacPage() {
		String view = "Mac";
		return view;

	}

	@RequestMapping(value = "/mac", method = RequestMethod.POST)
	public String getBackMacPage() {
		String view = "Mac";
		return view;

	}

	@RequestMapping("/filterApplicantsByName")
	public ModelAndView getFilterApplicantsPage() {
		ModelAndView view = new ModelAndView("filterApplicants",
				"progScheduled", new ProgramsScheduled());

		return view;
	}

	@RequestMapping(value = "filter", method = RequestMethod.POST)
	public ModelAndView filterApplicants(
			@ModelAttribute("progScheduled") ProgramsScheduled scheduled) {
		ModelAndView view = new ModelAndView();
		List<Application> list = service.retrieveFilteredApplicants(scheduled);
		if (!list.isEmpty()) {
			view.addObject("filteredApplicants", list);
			view.setViewName("Mac");
		}
		else {
			view.addObject("message", "No Applicant is available..!");
			view.setViewName("filterApplicants");
		}
		return view;

	}

	@RequestMapping(value = "updateStatus", method = RequestMethod.POST)
	public ModelAndView updateStatus(@RequestParam("button") String btnName,
			@RequestParam("applicantId") String appId,
			@RequestParam("doi") String doiDate) {
		ModelAndView view = new ModelAndView("filterApplicants","progScheduled",new ProgramsScheduled());
		String status = null;
		/*
		 * Random random = new Random(); int min = 2; int max = 5; int randVal =
		 * random.nextInt((max - min) + 1) + min;
		 */
		int randVal = 0;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate ldDate = LocalDate.parse(doiDate, formatter);
		LocalDate curDate = ldDate.plusDays(randVal);
		Date sqlDate = Date.valueOf(curDate);
		System.out.println(Integer.parseInt(appId));
		System.out.println(sqlDate);
		if (btnName.equalsIgnoreCase("accept")) {
			status = "accepted";
			service.updateApplicantStatus(status, Integer.parseInt(appId),
					sqlDate);
			view.addObject("message", "Applicants status is ACCEPTED");
			
		} else if(btnName.equalsIgnoreCase("reject")){
			status = "rejected";
			service.updateApplicantStatus(status, Integer.parseInt(appId),
					sqlDate);
			view.addObject("message", "Applicants status is REJECTED");
		}else{
			view.addObject("message", "Applicants status is NOT UPDATED");
		}
		return view;

	}

	@RequestMapping("viewApplicants")
	public ModelAndView getApplicants() {
		ModelAndView view = new ModelAndView("Mac");
		List<Application> list = service.displayApplicants();
		view.addObject("applicantList", list);
		return view;

	}

	@RequestMapping("viewParticipants")
	public ModelAndView getParticipants() {
		ModelAndView view = new ModelAndView("Mac");
		List<Participants> list = service.displayParticipants();
		view.addObject("participantList", list);
		return view;

	}

	@RequestMapping(value = "/confirmApplicants")
	public ModelAndView getConfirmApplicantsPage() {
		ModelAndView view = new ModelAndView("Mac");
		List<Application> list = service.getAcceptedApplicants();
		System.out.println(list);
		if (!list.isEmpty()) {
			view.addObject("accApplicantList", list);

		} else {
			view.addObject("message",
					"No participant available for confirmation");
		}

		return view;
	}

	@RequestMapping(value = "confirmReject", method = RequestMethod.POST)
	public ModelAndView confirmOrRejectApplicants(
			@RequestParam("applicantId") String id,
			@RequestParam("status") String status) {
		Integer applicantId = Integer.parseInt(id);
		String applicantStatus = null;
		ModelAndView view = new ModelAndView("Mac");
		if (status.equalsIgnoreCase("confirm")) {
			applicantStatus = "confirmed";
			view.addObject("message", "Applicant is CONFIRMED");

		} else if(status.equalsIgnoreCase("reject")) {
			applicantStatus = "rejected";
			view.addObject("message", "Applicant is REJECTED");
		}else{
			view.addObject("message", "Applicant status is not updated ");
		}

		service.confirmOrRejectApplicants(applicantId, applicantStatus);

		return view;

	}

	@RequestMapping("addParticipants")
	public ModelAndView addParticipants() {
		ModelAndView view=new ModelAndView("Mac");
		if(!service.addParticipantDetails().isEmpty()){
			view.addObject("message","Participants are added successfully..!" );
		}
		else
		{
			view.addObject("message","No Participant to Add" );	
		}
		return view;
		
		
		
	}
}
