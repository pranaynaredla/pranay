package com.cg.scheduleplanteacher.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.cg.scheduleplanteacher.bean.Teachers;

@Repository
@Transactional
public class SchedulePlanDaoImpl implements ISchedulePlanDao{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Integer addPlan(Teachers teachers) {
		entityManager.persist(teachers);
		//entityManager.flush();
		return null;
	}

}
