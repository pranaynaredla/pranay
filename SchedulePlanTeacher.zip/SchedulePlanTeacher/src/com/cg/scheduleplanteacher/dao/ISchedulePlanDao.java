package com.cg.scheduleplanteacher.dao;

import com.cg.scheduleplanteacher.bean.Teachers;

public interface ISchedulePlanDao {
	public Integer addPlan(Teachers teachers);
}
