package com.cg.scheduleplanteacher.dao;

import java.util.ArrayList;

import com.cg.scheduleplanteacher.bean.Teachers;

public interface ISchedulePlanDao {
	public Teachers addPlan(Teachers teachers);
	public ArrayList<Teachers> viewAllPlan();
	public ArrayList<Teachers> viewByPlanId(Integer id);
}
