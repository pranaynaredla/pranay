package com.cg.scheduleplanteacher.bean;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "schedule_teachers")
public class Teachers {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "faculty_id")
	private Integer facultyId;
	@Column(name = "faculty_name")
	@NotEmpty(message = "please fill")
	private String facultyName;
	@Column(name = "date")
	private String date;
	@Column(name = "fac_expert_in")
	@NotEmpty(message = "please fill")
	private String facultyExpertIn;
	@Column(name = "period")
	//@NotEmpty(message = "please fill")
	private String period;
	@Column(name = "comments")
	@NotEmpty(message = "please fill")
	private String comments;
	@Column(name = "email_id")
	@NotEmpty(message = "please fill")
	@Pattern(regexp = "[A-Za-z0-9]+[@][A-Za-z]+[.][A-Za-z]{1,4}", message = "Enter valid email")
	private String emailId;

	public Integer getFacultyId() {
		return facultyId;
	}

	public void setFacultyId(Integer facultyId) {
		this.facultyId = facultyId;
	}

	public String getFacultyName() {
		return facultyName;
	}

	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getFacultyExpertIn() {
		return facultyExpertIn;
	}

	public void setFacultyExpertIn(String facultyExpertIn) {
		this.facultyExpertIn = facultyExpertIn;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Teachers() {

	}

}
