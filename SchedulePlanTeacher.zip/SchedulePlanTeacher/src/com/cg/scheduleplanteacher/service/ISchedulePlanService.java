package com.cg.scheduleplanteacher.service;

import java.util.ArrayList;

import com.cg.scheduleplanteacher.bean.Teachers;

public interface ISchedulePlanService {

	public Teachers addPlan(Teachers teachers);
	public ArrayList<Teachers> viewAllPlan();
	public ArrayList<Teachers> viewByPlanId(Integer id);
}
