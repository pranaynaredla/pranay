package com.cg.scheduleplanteacher.service;

import com.cg.scheduleplanteacher.bean.Teachers;

public interface ISchedulePlanService {

	public Integer addPlan(Teachers teachers);

}
