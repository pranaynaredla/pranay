package com.cg.scheduleplanteacher.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.scheduleplanteacher.bean.Teachers;
import com.cg.scheduleplanteacher.dao.ISchedulePlanDao;

@Service
public class ScheduledPlanServiceImpl implements ISchedulePlanService{
	
	@Autowired
	ISchedulePlanDao planDao;

	@Override
	public Integer addPlan(Teachers teachers) {
		// TODO Auto-generated method stub
		return planDao.addPlan(teachers);
	}

}
