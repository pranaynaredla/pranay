package com.cg.scheduleplanteacher.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.scheduleplanteacher.bean.Teachers;
import com.cg.scheduleplanteacher.service.ISchedulePlanService;

@Controller
public class PlanController {
	
	@Autowired
	ISchedulePlanService schedulePlan;

	@RequestMapping("/index")
	public String getHomePage() {
		String view = null;
		view = "HomePage";
		return view;
	}

	@RequestMapping("/enterPlan")
	public ModelAndView enterPlan() {
		ModelAndView modelAndView = new ModelAndView("addFaculty", "tec",
				new Teachers());
		ArrayList<String> list = new ArrayList<String>();
		list.add("Maths");
		list.add("Physics");
		list.add("Chemistry");
		list.add("Biology");
		list.add("English");
		modelAndView.addObject("subjects", list);
		return modelAndView;
	}

	@RequestMapping(value = "/store", method = RequestMethod.POST)
	public ModelAndView addDetails(@ModelAttribute("tec") @Valid Teachers teachers,
			BindingResult bindingResult,Model m) {
		ModelAndView view=new ModelAndView();
		if (bindingResult.hasErrors()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add("Maths");
			list.add("Physics");
			list.add("Chemistry");
			list.add("Biology");
			list.add("English");
			view.addObject("subjects", list);
			view.setViewName("addFaculty");
		}
		else{
			Integer id=schedulePlan.addPlan(teachers);
			view.setViewName("success");
		}
		return view;
	}

	@RequestMapping("/viewAll")
	public ModelAndView viewAllPlans() {

		return null;
	}

	@RequestMapping("/viewById")
	public ModelAndView viewByPlanId() {

		return null;
	}
}
