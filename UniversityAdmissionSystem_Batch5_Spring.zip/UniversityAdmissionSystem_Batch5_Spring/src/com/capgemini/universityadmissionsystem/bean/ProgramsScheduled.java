package com.capgemini.universityadmissionsystem.bean;

import java.io.Serializable;
import java.sql.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "Programs_scheduled")
@NamedQuery(name = "getProgramsScheduled", query = "select programsScheduled from ProgramsScheduled programsScheduled")
public class ProgramsScheduled implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "scheduled_program_id")
	@NotEmpty(message = "Please enter Scheduled Program ID.... This is a required field")
	private String scheduledProgramId;

	@Column(name = "program_name")
	@NotEmpty(message = "Please enter Program Name.... This is a required field")
	private String programName;

	@Column(name = "location")
	@NotEmpty(message = "Please enter location.... This is a required field")
	private String location;

	@Transient
	private String sDate;

	@Transient
	private String eDate;
	
	@Column(name = "start_date")
	@Past
	@NotEmpty(message = "Please enter Start Date.... This is a required field")
	private Date startDate;

	@Column(name = "end_date")
	@NotEmpty(message = "Please enter End Date.... This is a required field")
	private Date endDate;

	@Column(name = "sessions_per_week")
	@NotEmpty(message = "Please enter Sessions Per Week.... This is a required field")
	@Size(min = 2, max = 6)
	private Integer sessionsPerWeek;

	public ProgramsScheduled() {
	}

	
	public String getsDate() {
		return sDate;
	}


	public void setsDate(String sDate) {
		this.sDate = sDate;
	}


	public String geteDate() {
		return eDate;
	}


	public void seteDate(String eDate) {
		this.eDate = eDate;
	}


	public String getScheduledProgramId() {
		return scheduledProgramId;
	}

	public void setScheduledProgramId(String scheduledProgramId) {
		this.scheduledProgramId = scheduledProgramId;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Integer getSessionsPerWeek() {
		return sessionsPerWeek;
	}

	public void setSessionsPerWeek(Integer sessionsPerWeek) {
		this.sessionsPerWeek = sessionsPerWeek;
	}

	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="scheduled_program_id")
	private Set<Application> applications;

	public Set<Application> getApplications() {
		return applications;
	}

	public void setApplications(Set<Application> applications) {
		this.applications = applications;
	}
}
