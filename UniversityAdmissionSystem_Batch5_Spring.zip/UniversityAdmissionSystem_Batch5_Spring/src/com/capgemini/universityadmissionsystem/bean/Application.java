package com.capgemini.universityadmissionsystem.bean;

import java.io.Serializable;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "Application")
@NamedQuery(name="getApplicants",query="SELECT applicant FROM Application applicant")
//@NamedQuery(name="filterApplicants", query="SELECT a.applicantId,a.fullName,a.marksObtained,a.highestQualification FROM Application a JOIN ProgramsScheduled p ON a.scheduledProgramId=p.scheduledProgramId WHERE p.programName=:pname")
public class Application implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "applicant_id")
	private Integer applicantId;
	@NotEmpty(message="Please enter yor Name.....This is a required field")
	@Pattern(regexp="^[A-Za-z ]{3,20}$" ,message="Please enter valid Full Name..It should not contain any digits")
	@Column(name = "full_name")
	private String fullName;
	@Transient
	@NotEmpty(message="Please enter yor Date of Birth.....This is a required field")
	private String dob;
	@Column(name = "date_of_birth")
	private Date dateOfBirth;
	@Column(name = "highest_qualification")
	@NotEmpty(message="Please select your Qualification.....This is a required field")
	private String highestQualification;
	@Column(name = "marks_obtained")
	@NotNull(message="Please enter your Marks.....This is a required field")
	private Integer marksObtained;
	@Column(name = "goals")
	@NotEmpty(message="Please enter yor Goals.....This is a required field")
	@Pattern(regexp="^[A-Za-z0-9 ]{1,20}$" ,message="Goals should not exceed more than 20 characters")
	private String goals;
	@Column(name = "email_id")
	@Pattern(regexp="[A-Za-z0-9]+@[A-Za-z0-9.-]+[.][A-Za-z]{2,4}",message="Invalid email address")
	private String emailId;
	@Column(name = "scheduled_program_id")
	@NotEmpty(message="Please enter Scheduled program ID.....This is a required field")
	private String scheduledProgramId;
	@Column(name = "status")
	private String status;
	@Column(name = "date_of_interview")
	private Date dateOfInterview;

	public Application() {
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public Integer getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(Integer applicantId) {
		this.applicantId = applicantId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getHighestQualification() {
		return highestQualification;
	}

	public void setHighestQualification(String highestQualification) {
		this.highestQualification = highestQualification;
	}

	public Integer getMarksObtained() {
		return marksObtained;
	}

	public void setMarksObtained(Integer marksObtained) {
		this.marksObtained = marksObtained;
	}

	public String getGoals() {
		return goals;
	}

	public void setGoals(String goals) {
		this.goals = goals;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getScheduledProgramId() {
		return scheduledProgramId;
	}

	public void setScheduledProgramId(String scheduledProgramId) {
		this.scheduledProgramId = scheduledProgramId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getDateOfInterview() {
		return dateOfInterview;
	}

	public void setDateOfInterview(Date dateOfInterview) {
		this.dateOfInterview = dateOfInterview;
	}

	@Override
	public String toString() {
		return "Application [applicantId=" + applicantId + ", fullName=" + fullName + ", dob=" + dob + ", dateOfBirth="
				+ dateOfBirth + ", highestQualification=" + highestQualification + ", marksObtained=" + marksObtained
				+ ", goals=" + goals + ", emailId=" + emailId + ", scheduledProgramId=" + scheduledProgramId
				+ ", status=" + status + ", dateOfInterview=" + dateOfInterview + "]";
	}

}
