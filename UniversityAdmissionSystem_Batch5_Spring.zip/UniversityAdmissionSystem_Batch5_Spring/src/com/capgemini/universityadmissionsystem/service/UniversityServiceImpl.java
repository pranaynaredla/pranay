package com.capgemini.universityadmissionsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.universityadmissionsystem.bean.Application;
import com.capgemini.universityadmissionsystem.bean.Participants;
import com.capgemini.universityadmissionsystem.bean.ProgramsOffered;
import com.capgemini.universityadmissionsystem.bean.ProgramsScheduled;
import com.capgemini.universityadmissionsystem.bean.Users;
import com.capgemini.universityadmissionsystem.dao.IUniversityDao;

@Service
public class UniversityServiceImpl implements IUniversityService{
	
	@Autowired
	IUniversityDao dao;

	@Override
	public List<Users> authenticateUser(Users users) {
		return dao.authenticateUser(users);
	}

	@Override
	public List<ProgramsOffered> displayProgramsOffered() {
	
		return dao.displayProgramsOffered();
	}

	@Override
	public List<ProgramsScheduled> displayProgramsScheduled() {
		return dao.displayProgramsScheduled();
	}

	@Override
	public Integer addApplicantDetails(Application application) {
		return dao.addApplicantDetails(application);
	}

	@Override
	public List<Application> retrieveFilteredApplicants(ProgramsScheduled scheduled) {
		return dao.retrieveFilteredApplicants(scheduled);
	}

	@Override
	public List<Application> applicantStatus(Integer id) {
		// TODO Auto-generated method stub
		return dao.applicantStatus(id);
	}

	@Override
	public List<Participants> displayParticipants() {
		// TODO Auto-generated method stub
		return dao.displayParticipants();
	}

	@Override
	public List<Application> displayApplicants() {
		// TODO Auto-generated method stub
		return dao.displayApplicants();
	}

}
