package com.capgemini.universityadmissionsystem.service;

import java.util.List;

import com.capgemini.universityadmissionsystem.bean.Application;
import com.capgemini.universityadmissionsystem.bean.Participants;
import com.capgemini.universityadmissionsystem.bean.ProgramsOffered;
import com.capgemini.universityadmissionsystem.bean.ProgramsScheduled;
import com.capgemini.universityadmissionsystem.bean.Users;

public interface IUniversityService {
	
	public List<Users> authenticateUser(Users users);
	public List<ProgramsOffered> displayProgramsOffered();
	public List<ProgramsScheduled> displayProgramsScheduled();
	public Integer addApplicantDetails(Application application);
	public List<Application> retrieveFilteredApplicants(ProgramsScheduled scheduled);
	public List<Application> applicantStatus(Integer id);
	public List<Participants> displayParticipants();
	public List<Application> displayApplicants();
}
