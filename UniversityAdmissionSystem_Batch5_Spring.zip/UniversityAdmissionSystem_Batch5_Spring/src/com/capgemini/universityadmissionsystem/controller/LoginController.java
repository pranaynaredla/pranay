package com.capgemini.universityadmissionsystem.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.universityadmissionsystem.bean.Users;
import com.capgemini.universityadmissionsystem.service.IUniversityService;

@Controller
public class LoginController {

	@Autowired
	IUniversityService service;

	@RequestMapping("index")
	public String getHome() {
		return "Home";

	}

	@RequestMapping(value = "/login")
	public String getLogin(Model model) {
		Users users = new Users();
		List<String> roleList = getRoleList();
		model.addAttribute("userKey", users);

		model.addAttribute("roleList", roleList);

		return "login";
	}

	private List<String> getRoleList() {

		List<String> list = new ArrayList<String>();
		list.add("admin");
		list.add("mac");

		return list;

	}

	@RequestMapping(value = "Valid", method = RequestMethod.POST)
	public ModelAndView validateUser(
			@ModelAttribute("userKey") @Valid Users users,
			BindingResult result, Model model) {

		ModelAndView view = new ModelAndView();
		if (result.hasErrors()) {
			view = new ModelAndView("login", "userKey", users);
		} else {
			if (service.authenticateUser(users) != null && users.getRole().equals("mac")) {
				view.setViewName("Mac");
			}
			else if(service.authenticateUser(users) != null && users.getRole().equals("admin")){
				view.setViewName("Admin");	
			}
			else{
				view = new ModelAndView("login", "userKey", users);
			}
		}
		return view;

	}
}
