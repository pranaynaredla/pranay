package com.capgemini.universityadmissionsystem.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.universityadmissionsystem.bean.Application;
import com.capgemini.universityadmissionsystem.bean.Participants;
import com.capgemini.universityadmissionsystem.bean.ProgramsOffered;
import com.capgemini.universityadmissionsystem.bean.ProgramsScheduled;
import com.capgemini.universityadmissionsystem.service.IUniversityService;

@Controller
public class MacController {
	
	@Autowired
	IUniversityService service;
	
	@RequestMapping(value="/mac")
	public String getMacPage() {
		String view="Mac";
		return view;
		
	}
	

	private List<String> getProgramList() {

		List<String> list = new ArrayList<String>();
		list.add("ML");
		list.add("DA");
		list.add("BD");
		list.add("AI");
		list.add("JAVA");
		return list;

	}
	
	@RequestMapping("/filterApplicantsByName")
	public ModelAndView getFilterApplicantsPage() {
		ModelAndView view=new ModelAndView("filterApplicants","progScheduled",new ProgramsScheduled());
		List<String> list=getProgramList();
		view.addObject("programList", list);
		return view;	
	}

	@RequestMapping(value="filter",method=RequestMethod.POST)
	public ModelAndView filterApplicants(@ModelAttribute("progScheduled") ProgramsScheduled scheduled) {
		ModelAndView view=new ModelAndView("filterApplicants");
		List<Application> list=service.retrieveFilteredApplicants(scheduled);
		if(!list.isEmpty())
		view.addObject("filteredApplicants", list);
		else
		view.addObject("errorMsg", "No Applicant is available..!");

		return view;
		
	}
	
	@RequestMapping(value="updateStatus", method=RequestMethod.POST)
	public ModelAndView updateStatus() {
		ModelAndView view=new ModelAndView("Home");
		
		
		return view;
		
	}
	
	@RequestMapping("viewApplicants")
	public ModelAndView getApplicants() {
		ModelAndView view = new ModelAndView("Mac");
		List<Application> list = service.displayApplicants();
		view.addObject("applicantList", list);
		return view;
		
	}
	
	@RequestMapping("viewParticipants")
	public ModelAndView getParticipants() {
		ModelAndView view = new ModelAndView("Mac");
		List<Participants> list = service.displayParticipants();
		view.addObject("participantList", list);
		return view;
		
	}
}
