package com.capgemini.universityadmissionsystem.dao;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.universityadmissionsystem.bean.Application;
import com.capgemini.universityadmissionsystem.bean.Participants;
import com.capgemini.universityadmissionsystem.bean.ProgramsOffered;
import com.capgemini.universityadmissionsystem.bean.ProgramsScheduled;
import com.capgemini.universityadmissionsystem.bean.Users;

@Repository
@Transactional
public class UniversityDaoImpl implements IUniversityDao {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<Users> authenticateUser(Users users) {
		TypedQuery<Users> query = entityManager
				.createQuery(
						"SELECT user FROM Users user WHERE user.loginId=:loginId AND user.password=:password AND user.role=:role",
						Users.class);
		query.setParameter("loginId", users.getLoginId());
		query.setParameter("password", users.getPassword());
		query.setParameter("role", users.getRole());
		return query.getResultList();
	}

	@Override
	public List<ProgramsOffered> displayProgramsOffered() {
		Query query = entityManager.createNamedQuery("getProgamsOffered");
		return query.getResultList();

	}

	@Override
	public List<ProgramsScheduled> displayProgramsScheduled() {
		Query query = entityManager.createNamedQuery("getProgramsScheduled");
		return query.getResultList();

	}

	@Override
	public Integer addApplicantDetails(Application application) {
		String string = null;
		LocalDate curDate=LocalDate.now();
		Date curSqlDate = Date.valueOf(curDate);
		java.util.Date date = null;
		Date sqlDate = null;
		string = application.getDob();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		try {
			date = dateFormat.parse(string);
			sqlDate = new Date(date.getTime());
			application.setDateOfBirth(sqlDate);
			application.setStatus("applied");
			application.setDateOfInterview(curSqlDate);
			entityManager.persist(application);
			entityManager.flush();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return application.getApplicantId();
	}

	@Override
	public List<Application> retrieveFilteredApplicants(ProgramsScheduled scheduled) {
		/*Query query=entityManager.createQuery("SELECT a.applicantId,a.fullName,a.marksObtained,a.highestQualification FROM Application a JOIN ProgramsScheduled p ON a.scheduledProgramId=p.scheduledProgramId WHERE p.programName=:pname");*/
		Query query=entityManager.createQuery("from ProgramsScheduled as ps join ps.applications as app");
		//query.setParameter("pname",scheduled.getProgramName());
		return query.getResultList();
	}

	@Override
	public List<Application> applicantStatus(Integer id) {
		Query query=entityManager.createQuery("SELECT application.status,application.dateOfInterview FROM Application application WHERE application.applicantId=:id");
		query.setParameter("id", id);
		return query.getResultList();
	}

	@Override
	public List<Participants> displayParticipants() {
		Query query = entityManager.createNamedQuery("getParticipants");
		return query.getResultList();
	}

	@Override
	public List<Application> displayApplicants() {
		Query query = entityManager.createNamedQuery("getApplicants");
		return query.getResultList();
	}

}
