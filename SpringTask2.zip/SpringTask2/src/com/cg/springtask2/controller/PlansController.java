package com.cg.springtask2.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.springtask2.bean.Recharge;

@Controller
public class PlansController {
	@RequestMapping(value="/home")
	public String getHomePage(Model model){
		Recharge recharge=new Recharge();
		model.addAttribute("recKey", recharge);
		return "link";
	}
	@RequestMapping(value="/Viewall")
	public String viewAllPlans(){
		return "viewall";
	}
}
